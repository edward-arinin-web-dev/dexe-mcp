# Changelog

All notable changes to `@dexe-network/dexe-mcp` are recorded here. The format
follows [Keep a Changelog](https://keepachangelog.com/en/1.1.0/), and the
package uses [Semantic Versioning](https://semver.org/).

## 1.0.0-rc.1

First release of this package. Extracted from dexe-mcp 0.36.x/0.37.0 — the
history of the code up to this point is in the dexe-mcp repository.

- **54 read-only tools** for DeXe Protocol DAOs: DAO profiles and settings,
  treasury (with USD prices), proposals and their state, votes and voters,
  members, token holders, delegation, validators and experts, token sales,
  staking, protocol statistics, a one-call DAO report with a `since` diff, a
  cross-DAO inbox, proposal forecasts and treasury-risk analysis, IPFS reads,
  calldata and proposal decoding, and reads of external OpenZeppelin / Compound
  Bravo Governors (Uniswap, Compound, Optimism). Catalog: [docs/TOOLS.md](docs/TOOLS.md).
- **One binary, two transports:** `dexe-mcp-read` serves MCP over stdio;
  `dexe-mcp-read serve-http` serves the same tools over MCP Streamable HTTP,
  stateless, for remote clients ([docs/REMOTE.md](docs/REMOTE.md)).
- **Zero config:** public BSC RPCs, the DeXe subgraph endpoints, the DeXe
  backend and public IPFS gateways are built in. `dexe_doctor` reports what an
  own RPC, Graph key or gateway would improve ([docs/ENVIRONMENT.md](docs/ENVIRONMENT.md)).
- **Read-only by construction:** no signing, broadcasting, uploading or local
  state. A test walks the binary's import graph. Loading the config deletes
  every `DEXE_*` / `AGENT_*` / `SWARM_*` var the server does not read — an
  allowlist, so a signing key in a shared `.env`, or a var a newer write edition
  adds, leaves the process before anything can read it. `dexe_dao_report` takes an explicit `since`
  anchor (ISO time, Unix seconds or `block:<n>`) because no snapshots are
  stored.
- **Library exports:** `@dexe-network/dexe-mcp` exports `createReadServer`,
  `createReadServerFactory`, `loadReadConfig` and `READ_TOOLS`;
  `@dexe-network/dexe-mcp/core` exports the lower-level building blocks
  (config, RPC, multicall, subgraph / backend / IPFS readers, units, risk math,
  the knowledge engine, register functions for every read tool, the env spec);
  `@dexe-network/dexe-mcp/bin` exports `runReadBin(argv, { version, pkgDir })`,
  the `dexe-mcp-read` binary as a function — importing it starts nothing — for
  a package that ships it under its own bin entry;
  `@dexe-network/dexe-mcp/testing` exports helpers for testing such a package
  (the doctor engine, the env parser, report and annotation helpers) with **no
  semver promise**. Type declarations included.
- **Decoding without a compile step:** an ABI snapshot of the DeXe Protocol
  contracts ships in the package.
- **Hardened for shared hosting:** input `maxItems` bounds, a 2 MB IPFS cap, a
  256 KB result cap, untrusted-text fencing, secret scrubbing and endpoint
  labels, `Host` / `Origin` allowlists, per-IP rate limits and an in-flight cap
  ([SECURITY.md](SECURITY.md)).
- **OpenAI apps domain verification:** `serve-http` answers
  `GET /.well-known/openai-apps-challenge` with `DEXE_HTTP_OPENAI_CHALLENGE` as
  `text/plain` (404 when unset), Host-checked and rate-limited, without the
  Origin check ([docs/REMOTE.md](docs/REMOTE.md#openai-domain-verification)).
- **Docker image** `ghcr.io/dexe-network/dexe-mcp`: one bundled file on
  `node:22-slim`, non-root, writes nothing to disk (runs with a read-only root
  filesystem), health check on
  `/healthz`.
- **Claude Code plugin:** the bundled server plus the `dexe-report` and
  `dexe-setup` skills, installable from this repository's marketplace.
- **MCP Registry:** `io.github.dexe-network/dexe-mcp`.
