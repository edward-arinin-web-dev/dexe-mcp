# Changelog

All notable changes to `@dexe-network/dexe-mcp` are recorded here. The format
follows [Keep a Changelog](https://keepachangelog.com/en/1.1.0/), and the
package uses [Semantic Versioning](https://semver.org/).

## Unreleased

- **MCP protocol 2026-07-28, next to 2025-11-25, on one endpoint.** The server
  now runs on the MCP TypeScript SDK v2 (`@modelcontextprotocol/server` 2.3)
  instead of v1 (`@modelcontextprotocol/sdk`). `serve-http` answers a
  2025-era `initialize` and a 2026-07-28 `server/discover` (and every later
  request of either era) at the same `/mcp`, after the same admission checks;
  2025-era answers keep today's JSON wire format. stdio serves both eras too.
  The access log gains an `era` field; a request whose `Accept` header admits
  no JSON is refused with 406 (`reason: "accept"`) in both eras
  ([docs/REMOTE.md](docs/REMOTE.md#protocol-versions)).
- **Fresh server per request.** The HTTP server pool is gone: the v2 SDK
  stamps per-request client identity on an instance, so every request (and
  every stdio connection) gets a new one. Requests that need no tool build
  none: notifications and posted responses get 202 straight away, and
  `initialize`, `server/discover`, `ping` and `subscriptions/listen` are
  answered by a tool-less server with the same identity and capabilities.
- **Abandoned work is bounded.** A request whose client went away (or that
  timed out) keeps a "draining" slot until its tool call actually ends;
  draining requests are capped at `DEXE_HTTP_MAX_INFLIGHT`, past which new
  requests get 503 (`reason: "draining"`). Work that outlives the drain limit
  counts as stuck, capped the same way (`reason: "stuck"`). The handshake,
  discovery, ping and listen are never refused for abandoned work. RPC reads
  now honour the request's cancellation: no new attempt, no backoff wait, no
  waiting on the pending one; ethers' sharing of identical requests is off, so
  one caller's cancel can never fail another caller's read.
- `subscriptions/listen` (2026-07-28) is refused with 406 when `Accept` does
  not allow `text/event-stream`; a body that is not a JSON-RPC object gets
  400 `-32600` (`reason: "invalid"`); a server that fails to build is logged
  with `reason: "factory"` in both eras.
- **Library (`@dexe-network/dexe-mcp`):** `createReadServer` and
  `createReadServerFromKit` return the v2 SDK's `McpServer`.
  `ReadServerFactory` is now `{ create, createLight, toolNames, built }` (was
  `acquire` / `release`); the `reuse` / `maxIdle` options are gone.
  `create({ track })` reports each tool call's promise; `createReadLightServer`
  builds the tool-less server. `ReadServerKit`
  replaces `toolsList` with `tools` and `schemas`. `READ_SERVER_CAPABILITIES`
  is new.
- **`./core` stays SDK-agnostic.** Register functions and the
  annotation / toolset / result-guard wrappers take structural `ToolServer` /
  `ResourceServer` types (new type exports) that both SDK majors' `McpServer`
  satisfy; the wrappers return the caller's own server type.
  `GovernorWriteTools` takes the server type as a parameter (default `any`, so
  a write half declared without one keeps its own server type). New:
  `applySchemaNormalizer` and `createSchemaJsonCache`, the v2 path of the
  tools/list schema normalizer; `installListToolsNormalizer` stays for v1.
  The core register functions register through `registerTool` and
  `registerResource` (no deprecated `server.tool()` / `server.resource()`).
- Advertised tool schemas no longer carry a root `$schema` (was draft-07):
  they use only keywords draft-07 and 2020-12 read alike, which a test pins.
  This applies on the v1 path (`installListToolsNormalizer`) too. Tools no
  longer carry `execution.taskSupport`.
- `@modelcontextprotocol/server` is pinned exactly: the era routing and the
  refusal filter depend on its classifier and error messages.

## 1.0.0-rc.1

First release of this package. Extracted from dexe-mcp 0.36.x/0.37.0 — the
history of the code up to this point is in the dexe-mcp repository.

- **54 read-only tools** for DeXe Protocol DAOs: DAO profiles and settings,
  treasury (with USD prices), proposals and their state, votes and voters,
  members, token holders, delegation, validators and experts, token sales,
  staking, protocol statistics, a one-call DAO report with a `since` diff, a
  cross-DAO inbox, proposal forecasts and treasury-risk analysis, IPFS reads,
  calldata and proposal decoding, and reads of external OpenZeppelin / Compound
  Bravo Governors (Uniswap, Compound, Optimism). Catalog: [docs/TOOLS.md](docs/TOOLS.md).
- **One binary, two transports:** `dexe-mcp-read` serves MCP over stdio;
  `dexe-mcp-read serve-http` serves the same tools over MCP Streamable HTTP,
  stateless, for remote clients ([docs/REMOTE.md](docs/REMOTE.md)).
- **Zero config:** public BSC RPCs, the DeXe subgraph endpoints, the DeXe
  backend and public IPFS gateways are built in. `dexe_doctor` reports what an
  own RPC, Graph key or gateway would improve ([docs/ENVIRONMENT.md](docs/ENVIRONMENT.md)).
- **Read-only by construction:** no signing, broadcasting, uploading or local
  state. A test walks the binary's import graph. Loading the config deletes
  every `DEXE_*` / `AGENT_*` / `SWARM_*` var the server does not read — an
  allowlist, so a signing key in a shared `.env`, or a var a newer write edition
  adds, leaves the process before anything can read it. `dexe_dao_report` takes an explicit `since`
  anchor (ISO time, Unix seconds or `block:<n>`) because no snapshots are
  stored.
- **Library exports:** `@dexe-network/dexe-mcp` exports `createReadServer`,
  `createReadServerFactory`, `loadReadConfig` and `READ_TOOLS`;
  `@dexe-network/dexe-mcp/core` exports the lower-level building blocks
  (config, RPC, multicall, subgraph / backend / IPFS readers, units, risk math,
  the knowledge engine, register functions for every read tool, the env spec);
  `@dexe-network/dexe-mcp/bin` exports `runReadBin(argv, { version, pkgDir })`,
  the `dexe-mcp-read` binary as a function — importing it starts nothing — for
  a package that ships it under its own bin entry;
  `@dexe-network/dexe-mcp/testing` exports helpers for testing such a package
  (the doctor engine, the env parser, report and annotation helpers) with **no
  semver promise**. Type declarations included.
- **Decoding without a compile step:** an ABI snapshot of the DeXe Protocol
  contracts ships in the package.
- **Hardened for shared hosting:** input `maxItems` bounds, a 2 MB IPFS cap, a
  256 KB result cap, untrusted-text fencing, secret scrubbing and endpoint
  labels, `Host` / `Origin` allowlists, per-IP rate limits and an in-flight cap
  ([SECURITY.md](SECURITY.md)).
- **OpenAI apps domain verification:** `serve-http` answers
  `GET /.well-known/openai-apps-challenge` with `DEXE_HTTP_OPENAI_CHALLENGE` as
  `text/plain` (404 when unset), Host-checked and rate-limited, without the
  Origin check ([docs/REMOTE.md](docs/REMOTE.md#openai-domain-verification)).
- **Docker image** `ghcr.io/dexe-network/dexe-mcp`: one bundled file on
  `node:22-slim`, non-root, writes nothing to disk (runs with a read-only root
  filesystem), health check on
  `/healthz`.
- **Claude Code plugin:** the bundled server plus the `dexe-report` and
  `dexe-setup` skills, installable from this repository's marketplace.
- **MCP Registry:** `io.github.dexe-network/dexe-mcp`.
