# DeXe MCP — read-only DAO data for AI agents

`@dexe-network/dexe-mcp` is an [MCP](https://modelcontextprotocol.io) server
that lets an AI assistant read everything about
[DeXe Protocol](https://dexe.io) DAOs: profiles and settings, treasury,
proposals and their state, votes and voters, members, token holders,
delegation, validators and experts, token sales, staking and protocol
statistics — plus external OpenZeppelin / Compound Governor DAOs (Uniswap,
Compound, Optimism).

- **54 tools, all read-only.** Nothing signs, sends, uploads or stores
  anything. For actions, the assistant can point the user to the DAO on
  [app.dexe.io](https://app.dexe.io).
- **Zero config.** Public BSC RPCs, the DeXe subgraph endpoints, the DeXe
  backend and public IPFS gateways are built in. Add your own endpoints only
  for reliability.
- **One call for a whole DAO.** `dexe_dao_report` returns every section —
  members, delegations, treasury, proposals, turnout, deadlines — and can show
  only what changed since a given time.
- **Local or remote.** `dexe-mcp-read` runs over stdio for Claude Code, Claude
  Desktop, Cursor and other MCP hosts, and `dexe-mcp-read serve-http` serves the
  same tools over Streamable HTTP.

Chains: BNB Smart Chain mainnet (56, default) and testnet (97); Ethereum (1) and
Optimism (10) for the external Governors.

## Install

### Claude Code

```bash
claude mcp add dexe-read -- npx -y -p @dexe-network/dexe-mcp dexe-mcp-read
```

Or as a plugin, which also installs the `dexe-report` and `dexe-setup` skills
and runs a bundled copy of the server (no `npx` at launch):

```
/plugin marketplace add dexe-network/dexe-mcp
/plugin install dexe-read@dexe-network
```

### Claude Desktop, Cursor and other MCP clients

```json
{
  "mcpServers": {
    "dexe-read": {
      "command": "npx",
      "args": ["-y", "-p", "@dexe-network/dexe-mcp", "dexe-mcp-read"]
    }
  }
}
```

Requires Node.js 20.12 or later. On Windows, if the client cannot start `npx`,
use `"command": "cmd"` with `"args": ["/c", "npx", "-y", "-p", "@dexe-network/dexe-mcp", "dexe-mcp-read"]`,
or install globally (`npm i -g @dexe-network/dexe-mcp`) and run
`"command": "node"` with the path to `dist/read/bin.js` in the global
`node_modules`.

### Remote clients (Claude.ai, ChatGPT) — coming

A hosted endpoint is not live yet. Once it is, add it by URL with no
authentication:

- **Claude.ai:** Customize > Connectors > Add custom connector,
  `https://{{MCP_HOST}}/mcp`.
- **ChatGPT:** developer mode, create an app for `https://{{MCP_HOST}}/mcp`.

To host your own endpoint now, see [docs/REMOTE.md](docs/REMOTE.md) — the
Docker image is `ghcr.io/dexe-network/dexe-mcp`.

## Try it

Ask your assistant, for example:

- "List the largest DeXe DAOs on BSC."
- "Give me a full report on DAO 0x… — what changed in the last 7 days?"
- "Which proposals in my DAOs still need my vote? My wallet is 0x…"
- "Will proposal 12 in DAO 0x… reach quorum?"
- "What is the current state of Uniswap proposal 75?"

## Tools

All 54 tools are served in every session; there are no profiles to pick. Full
list with descriptions: [docs/TOOLS.md](docs/TOOLS.md) (also the MCP resource
`dexe://tools`).

| Group | Tools |
| --- | --- |
| Orientation and diagnostics | `dexe_context`, `dexe_guide`, `dexe_doctor`, `dexe_get_config` |
| DAO, proposal and vote reads | `dexe_dao_info`, `dexe_dao_registry_lookup`, `dexe_dao_predict_addresses`, `dexe_proposal_state`, `dexe_proposal_list`, `dexe_proposal_voters`, `dexe_vote_user_power`, `dexe_vote_get_votes` |
| On-chain and backend reads | `dexe_read_multicall`, `dexe_read_treasury`, `dexe_read_token_holders`, `dexe_read_dao_stats`, `dexe_read_nfts`, `dexe_read_validators`, `dexe_read_settings`, `dexe_read_protocol_stats`, `dexe_read_expert_status`, `dexe_read_token_sale_tiers`, `dexe_read_token_sale_user`, `dexe_read_distribution_status`, `dexe_read_staking_info`, `dexe_read_privacy_policy_status` |
| Subgraph reads | `dexe_graph_query`, `dexe_graph_schema`, `dexe_read_dao_list`, `dexe_read_dao_members`, `dexe_read_dao_experts`, `dexe_read_delegation_map`, `dexe_read_user_activity`, `dexe_read_validator_list` |
| Token-sale reads | `dexe_read_token_sales`, `dexe_read_token_sale_position` |
| Reporting and analysis | `dexe_dao_report`, `dexe_user_inbox`, `dexe_proposal_forecast`, `dexe_proposal_risk_assess` |
| IPFS | `dexe_ipfs_fetch`, `dexe_ipfs_cid_info` |
| Decoding and GovPool contract reads | `dexe_read_gov_state`, `dexe_list_gov_contract_types`, `dexe_decode_calldata`, `dexe_decode_proposal` |
| External Governors | `dexe_gov_list_governors`, `dexe_gov_get_proposal`, `dexe_gov_get_voting_power`, `dexe_gov_get_quorum`, `dexe_gov_get_proposal_threshold`, `dexe_gov_get_state`, `dexe_gov_has_voted`, `dexe_gov_simulate_vote_impact` |

Resources: `dexe://graph-schema` (subgraph entities and fields), `dexe://tools`
(the catalog) and `dexe://playbook` (reading topics, pitfalls, error remedies).

## Configuration

Nothing is required. Optional variables go in `~/.dexe-mcp/.env` (or `./.env`,
or a file named by `DEXE_ENV_FILE`); restart the MCP host after editing. The
most useful ones:

```env
DEXE_RPC_URL_MAINNET=https://<your-bsc-rpc>        # reliable BSC reads
DEXE_SUBGRAPH_POOLS_URL=https://gateway.thegraph.com/api/<key>/subgraphs/id/<pools-id>
DEXE_IPFS_GATEWAY=https://<your-ipfs-gateway>
DEXE_RPC_URL_1=https://<your-ethereum-archive-rpc> # external Governors on Ethereum
```

Setting any RPC turns the built-in public BSC fallback off, so set every chain
you read. Run `dexe_doctor` (or the `/dexe-setup` skill) to see what is
configured and what would help. Every variable:
[docs/ENVIRONMENT.md](docs/ENVIRONMENT.md).

## Use as a library

```ts
import { serveStdio } from "@modelcontextprotocol/server/stdio";
import { createReadServerFactory, loadReadConfig } from "@dexe-network/dexe-mcp";

const factory = createReadServerFactory(await loadReadConfig(), { remote: false, version: "1.0.0" });
// Serves MCP protocol 2025-11-25 and 2026-07-28: the client's opening message picks the era.
serveStdio(() => factory.create());
```

The server is the MCP TypeScript SDK v2 `McpServer` (`@modelcontextprotocol/server`).

`@dexe-network/dexe-mcp/core` exports the building blocks the server is made
of — config and chain resolution, RPC and multicall, the subgraph, backend and
IPFS readers, units, risk math, the knowledge engine and the register function
of every read tool — for programs that compose their own server. Type
declarations are included. The register functions take any MCP server with a
`registerTool` method — the v2 SDK's `McpServer` or the v1 SDK's
(`@modelcontextprotocol/sdk`) — and name no SDK type.

## Documentation

- [docs/TOOLS.md](docs/TOOLS.md) — every tool
- [docs/ENVIRONMENT.md](docs/ENVIRONMENT.md) — every variable, chains, subgraphs, pitfalls
- [docs/REMOTE.md](docs/REMOTE.md) — `serve-http`, Docker, reverse proxy, limits
- [docs/REPORTING.md](docs/REPORTING.md) — `dexe_dao_report`, `since` diffs, `/loop` and `/schedule`
- [docs/INBOX.md](docs/INBOX.md) — inbox, forecast, token-sale discovery
- [docs/GRAPH.md](docs/GRAPH.md) — subgraph entities for `dexe_graph_query`
- [docs/GOVERNOR.md](docs/GOVERNOR.md) — external Governor reads and their RPC setup
- [SECURITY.md](SECURITY.md) — threat model and how to report a vulnerability
- [CHANGELOG.md](CHANGELOG.md)

## Building and signing transactions

This package only reads. A separate package,
[`dexe-mcp`](https://www.npmjs.com/package/dexe-mcp), adds transaction building
and signing for DeXe DAOs on top of it. It is maintained independently and is
not required for anything described here.

## Development

```bash
npm ci
npm run typecheck
npm run build
npm test
```

`npm run bundle:read` builds the single-file server used by the Docker image;
`npm run bundle:plugin` rebuilds the plugin bundle.

## License

[MIT](LICENSE)
