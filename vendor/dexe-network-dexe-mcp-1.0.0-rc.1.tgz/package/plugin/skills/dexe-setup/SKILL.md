---
name: dexe-setup
description: |
  Setup check for the read-only DeXe MCP server (dexe-mcp-read). Explains that
  every tool works with ZERO config, then walks the user through the optional
  upgrades — their own RPC, a Graph API key / subgraph URLs, a dedicated IPFS
  gateway, archive RPCs for the external Governor chains — saying what each one
  improves. Drives from `dexe_doctor`, edits `.env` (NEVER the MCP host config's
  env block), and tells the user to restart. Triggered by `/dexe-setup`, or when
  a tool reports a rate-limited public RPC, a subgraph 401/429, "shared public
  defaults", or an archive-read refusal on a Governor chain.
---

# dexe-setup

## What this does

`dexe-mcp-read` ships public defaults, so **all 54 tools work the moment it is
installed** — DAO info, treasury, proposals, votes, members, subgraph queries,
IPFS reads, external Governors. Nothing needs a key. This skill helps the user
replace shared defaults with their own endpoints when they want more
reliability, and fixes env mistakes. It drives from `dexe_doctor` — never guess
which file or variable is involved.

Open with:

> Everything already works on shared public endpoints. Configuring your own
> RPC, Graph key or IPFS gateway makes reads faster and less rate-limited.
> Want to set any of those up, or is the default fine?

If the default is fine, stop here.

## Step 1 — run the doctor

Call `dexe_doctor`. Read its rows:

- `pass` — nothing to do.
- `warn` — an advisory (for example `env.sharedDefaults`, `chain.publicRpcFallback`):
  an optional upgrade, not an error. A healthy zero-config install always has
  some.
- `fail` — something is broken; its remediation line says what to change.

`dexe_get_config` shows the resolved chains, default chain, subgraph coverage
per chain, backend and IPFS gateways.

## Step 2 — pick the upgrades

Offer only what the user's use needs:

| Upgrade | Variables | What it improves |
| --- | --- | --- |
| Own BSC RPC | `DEXE_RPC_URL_MAINNET` (56), `DEXE_RPC_URL_TESTNET` (97) | Public nodes rate-limit and lack archive history. Comma-separate several URLs for automatic failover. |
| Graph API key | `DEXE_SUBGRAPH_POOLS_URL`, `DEXE_SUBGRAPH_VALIDATORS_URL`, `DEXE_SUBGRAPH_INTERACTIONS_URL` (gateway URLs with the user's own key in the path) | The shared key is rate-limited. Affects members, delegation, voters, activity, DAO list, `dexe_graph_query`. |
| IPFS gateway | `DEXE_IPFS_GATEWAY` (+ `DEXE_PINATA_GATEWAY_TOKEN` for a private Pinata gateway) | Public gateways throttle; DAO and proposal descriptions load from IPFS. |
| Governor chains | `DEXE_RPC_URL_1` (Ethereum: Uniswap, Compound), `DEXE_RPC_URL_10` (Optimism) | Archive endpoints; the public ones refuse historical reads (voting power and quorum at a snapshot block). |

**Important:** setting any RPC variable turns the built-in public BSC fallback
off — even a Governor-only `DEXE_RPC_URL_1`. If the user sets one RPC, also set
the BSC chains they read and pin `DEXE_DEFAULT_CHAIN_ID=56`. With several RPCs
and no `DEXE_DEFAULT_CHAIN_ID`, the default chain becomes testnet (97).

Never use `DEXE_RPC_URL_MAINNET` for Ethereum: it means BSC chain 56.

## Step 3 — write `.env`

Edit a `.env` file, never the MCP host config's `env` block: a key set there
silently shadows every `.env` file. Where:

- `~/.dexe-mcp/.env` — works for `npx` and plugin installs, from any folder
  (recommended);
- `./.env` in the working directory;
- or a file named by `DEXE_ENV_FILE` (set in the real environment).

Example:

```env
DEXE_RPC_URL_MAINNET=https://<bsc-rpc>,https://<backup-bsc-rpc>
DEXE_RPC_URL_1=https://<ethereum-archive-rpc>
DEXE_DEFAULT_CHAIN_ID=56
DEXE_SUBGRAPH_POOLS_URL=https://gateway.thegraph.com/api/<key>/subgraphs/id/<pools-id>
DEXE_IPFS_GATEWAY=https://<gateway-host>
```

Parse rules: `KEY=value` with no spaces around `=`, comments on their own line,
no quotes unless needed, end the file with a newline.

If the user's `.env` also holds keys for other tools (signing keys, upload
credentials), leave them: this server ignores them and removes them from its
process at startup.

## Step 4 — restart and verify

The env is read once at startup. Tell the user to restart the MCP host (Claude
Code: restart the session or reconnect the server with `/mcp`; Claude Desktop:
quit and relaunch). Then call `dexe_doctor` again and confirm the `warn` rows the
user chose to fix are gone. Stop after three doctor → fix → restart rounds and
show the user the remaining rows instead of looping.

## Reference

`docs/ENVIRONMENT.md` lists every variable; `docs/GOVERNOR.md` covers the
Governor RPC setup.
