# External Governor DAOs — OpenZeppelin Governor and Compound Bravo

Eight `dexe_gov_*` reads target external OpenZeppelin Governor and
Compound-Bravo DAOs (Uniswap, Compound, Optimism). They are independent of the
DeXe Protocol: no DeXe contract needs to exist on the target chain.

| Tool | What it reads |
| --- | --- |
| `dexe_gov_list_governors` | Every bundled Governor config: chain, governor address, voting token, voting params, timelock (local, no network) |
| `dexe_gov_get_proposal` | Proposal state (name + enum index), snapshot and deadline blocks, for/against/abstain tallies |
| `dexe_gov_get_state` | `state(proposalId)` only, in one `eth_call` |
| `dexe_gov_has_voted` | Whether an account voted (OZ `hasVoted`, Bravo `getReceipt().hasVoted`; reports `method`) |
| `dexe_gov_get_voting_power` | `getPastVotes(account, block)`, or `getVotes(account)` when no block is given |
| `dexe_gov_get_quorum` | Quorum at a snapshot block (latest when omitted); reports the path taken in `method` |
| `dexe_gov_get_proposal_threshold` | Live `proposalThreshold()`, the configured value, and whether they agree |
| `dexe_gov_simulate_vote_impact` | Projects the outcome if `weight` were cast with `support`: current and projected tallies, `quorumMet`, `willPass` |

Every call takes a `governor` id — `uniswap`, `compound`, `optimism` — or that
DAO's own governor address. Nothing else resolves.

---

## Runtime RPC setup

The supported DAOs live on **Ethereum (chain 1)** and **Optimism (chain 10)**,
not on BSC. `DEXE_RPC_URL_MAINNET` / `DEXE_RPC_URL_TESTNET` are BSC chains 56 / 97
and do **not** cover them.

**Reads work with no configuration.** When a Governor chain has no RPC of its
own, the `dexe_gov_*` tools fall back to a shared public endpoint for that chain
and add an `rpc` note to the result saying so. The fallback goes through the same
provider as a configured chain — bounded timeout, retry, URL rotation, error
redaction.

Set your own endpoint for anything beyond a quick look. Any
`DEXE_RPC_URL_<chainId>` is registered automatically:

```
DEXE_RPC_URL_1=https://<your-ethereum-archive-rpc>    # Uniswap, Compound
DEXE_RPC_URL_10=https://<your-optimism-archive-rpc>   # Optimism
```

Use an **archive** endpoint. Governor reads are historical by construction —
`dexe_gov_get_voting_power` at a snapshot block, `dexe_gov_get_quorum` at a
snapshot block, and `dexe_gov_simulate_vote_impact`, which always reads quorum at
the proposal's snapshot. The free public endpoints answer latest-block reads and
refuse historical ones; the tools map that refusal to this advice rather than
relaying the vendor string.

Setting any RPC variable turns off the built-in BSC fallback (see
[ENVIRONMENT.md](./ENVIRONMENT.md#4-chains)). If you also read DeXe DAOs, set
`DEXE_RPC_URL_MAINNET` next to the Governor endpoints and pin
`DEXE_DEFAULT_CHAIN_ID=56`.

`DEXE_DISABLE_PUBLIC_RPC=1` turns the Governor fallback off — the tools then
return an error naming `DEXE_RPC_URL_<chainId>` instead of dialing a shared
endpoint. Use it on egress-restricted machines.

Use `DEXE_RPC_URL_<chainId>`, never `DEXE_RPC_URL_MAINNET`, for these chains:
that name means BSC chain 56 here. (`DEXE_RPC_URL_OPTIMISM` was never a
recognized variable.) Each tool resolves the RPC from the `chainId` in its
config, so no per-call chain argument is needed.

---

## Supported DAOs (Tier-1)

| DAO | Chain | Governor | Voting token | Family | Executor (timelock) |
| --- | --- | --- | --- | --- | --- |
| **Uniswap** | 1 (Ethereum) | `0x408ED6354d4973f66138C91495F2f2FCbd8724C3` | UNI (`ERC20VotesComp`) | Bravo v3 | `0x1a9C8182C09F50C8318d769245beA52c32BE35BC` (2d) |
| **Compound** | 1 (Ethereum) | `0x309a862bbC1A00e45506cB8A802D1ff10004c8C0` | COMP (`ERC20VotesComp`) | OZ v5 | `0x6d903f6003cca6255D85CcA4D3B5E5146dC33925` (2d) |
| **Optimism** | 10 (Optimism) | `0xcDF27F107725988f2261Ce2256bDfCdE8B382B10` | OP (`ERC20Votes`) | OZ v4 | `0x0eDd4B2cCCf41453D8B5443FBB96cc577d1d06bF` (3d) |

Each DAO is one JSON file under `src/governor/configs/`.

`votingDelay` / `votingPeriod` in the configs are **block counts** for all three
DAOs (none of them exposes an ERC-6372 `clock()` in seconds).

The configs are a **static snapshot**: a DAO can change its own parameters by
proposal. For a live number call `dexe_gov_get_proposal_threshold` or
`dexe_gov_get_quorum`; both echo the configured value under `configured`, and the
threshold tool also returns `configuredMatchesChain`.

### Voting parameters (as configured)

| DAO | `votingDelay` | `votingPeriod` | `proposalThreshold` | Quorum |
| --- | ---: | ---: | --- | --- |
| **Uniswap** | 13140 blocks | 40320 blocks | `1e24` (1,000,000 UNI) | fixed `quorumVotes()` = 40,000,000 UNI (4% of supply) |
| **Compound** | 13140 blocks | 19710 blocks | `25e21` (25,000 COMP) | fixed `quorum(block)` = 400,000 COMP |
| **Optimism** | 0 blocks | 259200 blocks | `0` | **approximation** — `votableSupply(block) × 30/100` |

> **Optimism's quorum value is an approximation, not a read.** OP keys
> `quorum(uint256)` by **proposalId** through its proposal-types configurator,
> so it cannot answer a bare block number. The config therefore sets
> `quorumSource: "votable-supply"`, and the quorum is computed as
> `votableSupply(block) × 30/100` from the default 3000-bps proposal type. A
> proposal created under a non-default type has a different threshold, and
> `dexe_gov_simulate_vote_impact` returns a `caveats` entry saying so. Treat the
> OP number as indicative; the other two are exact contract reads.

### Compound governance migration (2025)

Compound moved from **GovernorBravo `0xc0Da02939E1441F497fd74F78cE7Decb17B66529`**
to **CompoundGovernor `0x309a862bbC1A00e45506cB8A802D1ff10004c8C0`** (an OZ v5
governor with fractional counting).

- **Proposal ids `<= 393`** live on the retired Bravo contract and are **not
  readable** on the current governor. `dexe_gov_get_proposal`,
  `dexe_gov_get_state` and `dexe_gov_has_voted` append a hint naming the legacy
  address when a lookup for such an id fails; query that address directly.
- **Proposal ids `>= 394`** are on the current governor, which the `compound`
  config targets.
- Quorum counts **For votes only** (`COUNTING_MODE` = `quorum=for`). The config
  says so explicitly via `quorumCounting`.
- `dexe_gov_has_voted` reads `hasVoted()` on it.

---

## Family branching

The two Governor families have different on-chain signatures. The tools branch
internally on `governorVersion` in the config — callers do not need to.

| Surface | OZ v4 / v5 — Compound, Optimism | Compound Bravo (`bravo-v3`) — Uniswap |
| --- | --- | --- |
| **quorum** | `quorum(blockNumber)` | `quorumVotes()` (fixed) |
| **snapshot / deadline** | `proposalSnapshot` / `proposalDeadline` | flattened in `proposals(uint256)` |
| **has voted** | `hasVoted(proposalId, account)` | `getReceipt(proposalId, voter).hasVoted` |
| **votes interface** | `IVotes.getVotes` / `getPastVotes` | `ERC20VotesComp.getCurrentVotes` / `getPriorVotes` |

The voting-token interface is a **separate axis** from the governor family:
Compound is an OZ v5 governor whose token (COMP) still exposes the Compound-style
`getPriorVotes`. The config carries both independently.

So is **quorum counting**. The rule comes from the governor's own
`COUNTING_MODE()` (`quorumCounting` in the config), never from the ABI family:

| DAO | `COUNTING_MODE()` quorum clause | Counts toward quorum |
| --- | --- | --- |
| Uniswap | (Bravo — no `COUNTING_MODE`) | For |
| Compound | `quorum=for` | For |
| Optimism | `quorum=against,for,abstain` | For + Against + Abstain |

`dexe_gov_simulate_vote_impact` reports which rule it applied under
`quorum.counting`.

Result shapes are normalized — `dexe_gov_get_proposal` always returns
`{state, snapshotBlock, deadlineBlock, votes: {against, for, abstain}}`, plus
`bravoExtra` when applicable.

---

## Examples

### Read a recent Compound proposal (OZ v5)

```jsonc
// dexe_gov_get_proposal
{ "governor": "compound", "proposalId": "605" }

// → {
//   "governor": "compound",
//   "governorAddress": "0x309a862bbC1A00e45506cB8A802D1ff10004c8C0",
//   "chainId": 1,
//   "governorVersion": "oz-v5",
//   "proposalId": "605",
//   "state": { "index": 7, "name": "Executed" },
//   "snapshotBlock": "25918595",
//   "deadlineBlock": "25938594",
//   "votes": { "against": "0", "for": "687014600890789742662900", "abstain": "0" }
// }
```

### Read a Bravo proposal (Uniswap), with `bravoExtra`

```jsonc
// dexe_gov_get_proposal
{ "governor": "uniswap", "proposalId": "100" }

// → {
//   "governorVersion": "bravo-v3",
//   "state": { "index": 7, "name": "Executed" },
//   "votes": { "against": "...", "for": "...", "abstain": "..." },
//   "bravoExtra": { "proposer": "0x...", "eta": "...", "canceled": false, "executed": true }
// }
```

### Project the outcome of a 100k-UNI For vote

```jsonc
// dexe_gov_simulate_vote_impact
{
  "governor": "uniswap",
  "proposalId": "75",
  "support": 1,
  "weight": "100000000000000000000000"
}

// → {
//   "quorum": { "required": "40000000000000000000000000", "method": "quorumVotes()", "counting": "for" },
//   "currentTallies": { "against": "...", "for": "...", "abstain": "..." },
//   "projectedTallies": { "against": "...", "for": "...", "abstain": "..." },
//   "projection": { "quorumMet": true, "willPass": true }
// }
```

`support` is 0 = Against, 1 = For, 2 = Abstain. On Optimism the response also
carries a `caveats` array: `willPass` models quorum + (`for > against`) only,
and OP layers a per-proposal-type approval threshold and voting modules on top
of that, which are not modelled here.

---

## Keeping the configs honest

A Governor config is a static snapshot of mutable on-chain state, and governors
are upgradeable. `tests/governor/fixtures-live.test.ts` re-reads every config
from chain: the governor answers `name()`, `governorVersion` matches the
deployed ABI family, `timelock()` equals the configured timelock, the voting
params equal the live getters, the voting token matches, and quorum resolves
non-zero. It is skipped by default (no network in CI); run it with archive
endpoints before changing `src/governor/configs/`:

```sh
GOVERNOR_LIVE=1 DEXE_RPC_URL_1=https://<archive-rpc> DEXE_RPC_URL_10=https://<archive-rpc> npm run test:governor:live
```

---

## Out of scope

- Per-proposal-type quorum and approval thresholds (Arbitrum, and Optimism's
  own — approximated as described above)
- Aave's dual-track executor, Lido's Aragon agent, ve-token voting (Curve, GMX,
  Frax), MakerDAO Chief, Snapshot bridges
- Cross-chain proposal aggregation
