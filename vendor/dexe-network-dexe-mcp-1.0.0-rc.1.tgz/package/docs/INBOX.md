# Inbox, forecast and token-sale discovery

Three read tools for "what needs my attention?", "will this proposal pass?"
and "what sales does this DAO run?":

| Tool | Role |
|------|------|
| `dexe_user_inbox` | Pending items for one wallet across many DAOs — unvoted proposals, claimable rewards, deposited tokens |
| `dexe_proposal_forecast` | Pass-rate and quorum projection from a DAO's latest 10 proposals |
| `dexe_read_token_sales` | A DAO's token-sale tiers with status (`upcoming` / `active` / `ended` / `off`) |

For the position of one wallet in a sale (claimable, vesting, whitelist proof)
use `dexe_read_token_sale_position`.

## `dexe_user_inbox`

```jsonc
{
  "user": "0x…",
  "chainId": 56,             // default: the server's default chain
  "daos": ["0x…", "0x…"],    // optional on 56; required on chains without a pools subgraph
  "proposalScanLimit": 20    // default 20
}
```

Returns:

```jsonc
{
  "user": "0x…",
  "chainId": 56,
  "daoSource": "subgraph",   // "caller" when you passed daos[]
  "indexedChainId": 56,      // null when no subgraph was used
  "pendingItems": [
    { "dao": "0x…", "type": "unvotedProposal", "proposalId": "12", "deadline": "<unix seconds — voteEnd>" },
    { "dao": "0x…", "type": "claimableRewards", "proposalIds": ["8","9"], "totalAmount": "12000000000000000000" },
    { "dao": "0x…", "type": "lockedDeposit", "amount": "5000000000000000000000", "govToken": "0x…" }
  ],
  "summary": { "totalDaos": 2, "daosWithItems": 2, "criticalCount": 1 }
}
```

- **`unvotedProposal`** — a proposal in `Voting` / `ValidatorVoting` state the
  user has not voted on (personal vote).
- **`claimableRewards`** — non-zero pending rewards across the scanned proposal
  window (best-effort; older deployments without `getPendingRewards` return
  zero).
- **`lockedDeposit`** — tokens the user deposited into the DAO
  (`UserKeeper.tokenBalance(user, PersonalVote)`), which can be withdrawn on
  app.dexe.io.
- `criticalCount` counts unvoted proposals.

When `daos` is omitted, the tool asks the pools subgraph for the DAOs the user
has voter records in (limit 50). That works on BSC mainnet (56). On a chain
without a pools subgraph, pass `daos[]`: the scan itself is pure on-chain, and
the reply then carries `discoveryUnavailable`, saying that only the listed DAOs
were checked. This server keeps no record of DAOs between sessions, so there is
no other discovery source.

## `dexe_proposal_forecast`

```jsonc
{
  "govPool": "0x…",
  "draft": { "actionsOnFor": [...], "voteAmount": "10000000000000000000000" },  // optional
  "forceRpcOnly": false
}
```

Returns:

```jsonc
{
  "govPool": "0x…",
  "chain": 56,
  "quorum": {
    "settingRaw": "50000000000000000000000000",
    "quorumPct": 5,
    "totalPower": "4000000000000000000000000",
    "requiredWeight": "200000000000000000000000",
    "required": "200000000000000000000000",
    "projectedFor": "150000000000000000000000",
    "projectedPct": 75.0,
    "hitProbability": 0.75,
    "basis": "GovUserKeeper.getTotalPower() x GovSettings.getDefaultSettings().quorum / 1e27 — …"
  },
  "quorumNote": null,
  "historicalPassRate": { "last10": 7, "passed": 7, "decided": 9, "pending": 1, "total": 10, "ratio": 0.777… },
  "historicalQuorumAttainmentPct": 132.4,
  "history": [{ "proposalId": "9", "state": "ExecutedFor", "outcome": "passedFor",
                "requiredQuorum": "200000000000000000000000", "quorumAttainmentPct": 141.2, … }],
  "risks": ["quorumGap", "complexityRisk"],
  "recommendation": "borderline"
}
```

- Reads the latest 10 proposals and their final states.
- **Quorum has two units and this payload carries both.** `settingRaw` /
  `quorumPct` are the 1e25-scaled percentage SETTING
  (`GovSettings.getDefaultSettings().quorum`; 5e26 = 50%). `requiredWeight` —
  and its alias `required` — is the **absolute vote weight**
  `GovUserKeeper.getTotalPower() × quorum ÷ 1e27`, the same number
  `GovPool.getProposalRequiredQuorum(id)` returns. Compare `projectedFor`
  against the weight only.
- `projectedFor` = mean For-votes across the history + `draft.voteAmount`.
- `hitProbability` = `clamp(projectedFor / requiredWeight, 0, 1)` — an
  **attainment ratio**, not a statistical probability: 185% of target is
  reported as `1.0`.
- `recommendation` = `likelyPass` (>= 0.8) / `borderline` (>= 0.5) /
  `likelyFail` / `unknown`.
- `risks` can include `quorumGap`, `voterApathy` (pass rate under 40% of
  decided proposals), `complexityRisk` (more than 5 draft actions) and
  `quorumUnknown`.
- **Nullable when total power is unknown.** If `getTotalPower()` reverts or
  returns 0, `requiredWeight`, `projectedPct` and `hitProbability` are `null`,
  `recommendation` is `unknown`, `risks` includes `quorumUnknown`, and
  `quorumNote` explains why.
- The quorum used is the DAO's **default** settings. Internal, validator or
  custom-executor proposals can carry a different quorum. On-chain, quorum is
  reached by `votesFor` **or** `votesAgainst`; this projection tracks the For
  side only.
- `historicalPassRate.ratio` = `passed / decided`. A proposal still in
  `Voting` (or `Locked` / `ValidatorVoting` / `WaitingForVotingTransfer`) counts
  as `pending` and sits on neither side. An Against win is not a pass.
- Each `history` row carries its own `requiredQuorum` and `quorumAttainmentPct`,
  so the numbers stay comparable across a mid-history quorum change.
- The history cross-check uses the pools subgraph of the chain being forecast.
  A chain without one is forecast on-chain only (`subgraphHistory: null`, with
  `subgraphNote` saying why). `forceRpcOnly: true` skips the cross-check even
  where a subgraph exists.

## `dexe_read_token_sales`

```jsonc
{
  "govPool": "0x…",
  "tokenSaleProposal": "0x…",
  "chainId": 56
}
```

`tokenSaleProposal` is required here: this server keeps no record of DAO
deployments. Use the `govTokenSale` address from
`dexe_dao_predict_addresses(deployer, daoName)`, or take it from the DAO's
deploy receipt.

Returns:

```jsonc
{
  "govPool": "0x…",
  "tokenSaleProposal": "0x…",
  "chainId": 56,
  "tiers": [
    {
      "tierId": "1",
      "name": "Tier-A",
      "saleStartTime": "<unix seconds>",
      "saleEndTime": "<unix seconds>",
      "saleStartTimeUTC": "…",
      "saleEndTimeUTC": "…",
      "saleToken": "0x…",
      "purchaseTokens": ["0x…"],
      "totalProvided": "1000000000000000000000",
      "totalSold": "250000000000000000000",
      "status": "active"
    }
  ],
  "counts": { "upcoming": 0, "active": 1, "ended": 0, "off": 0 }
}
```

Reads `latestTierId()` then `getTierViews(0, latestTierId)`. `status` is `off`
when the tier's on-chain `isOff` flag is set, otherwise it is computed against
the current block timestamp:

- `now < saleStartTime` → `upcoming`
- `saleStartTime <= now <= saleEndTime` → `active`
- `now > saleEndTime` → `ended`

On-chain only, so it works on any chain with an RPC (56 and 97 included). Tier
names are written by the DAO and are returned as untrusted text.
