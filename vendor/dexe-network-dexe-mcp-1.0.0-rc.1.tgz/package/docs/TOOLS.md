# Tool catalog — `dexe-mcp-read`

**54 tools**, all read-only. None of them signs, sends, uploads or stores anything; every one is annotated `readOnlyHint: true`, `destructiveHint: false` and `idempotentHint: true`; `openWorldHint` is `true` for the 49 that reach an RPC, a subgraph, the DeXe backend or IPFS, and `false` for the 5 that answer locally. The list is `READ_TOOLS` in `src/editions.ts`; a test fails if the server registers anything else.

The server has no toolset profiles: all 54 tools are served in every session (`DEXE_TOOLSETS` has no effect). The same catalog is available in-band as the MCP resource `dexe://tools`, rendered from what the server actually registered.

Conventions that apply to most tools:

- `chainId` is optional and defaults to the server's default chain (BSC mainnet, 56, unless configured otherwise). Chain 97 is BSC testnet.
- Amounts are returned as raw base-unit strings; `requiredQuorum` and similar fields are absolute vote weights, not percentages.
- Subgraph-backed tools echo `indexedChainId`, the chain the rows came from. A chain with no subgraph endpoint returns an error naming the on-chain reads to use instead, never another chain's rows.
- Text written by third parties (DAO names, descriptions, IPFS content, token symbols) is returned fenced as untrusted data.
- Array inputs are bounded (for example 100 `calls`, 50 `daos`, 8 `chainIds`) and results are capped at 256 KB by default; see [REMOTE.md](./REMOTE.md#tool-level-limits).

## Orientation and diagnostics

| Tool | Title | What it does |
|---|---|---|
| `dexe_context` | Session context | Session orientation — configured chains and the default, env readiness (RPC/IPFS/subgraph/backend) and the tool set this server serves. Not needed once the DAO and chain are known. |
| `dexe_guide` | DAO data reading guide | (local, no network) Reference guide for reading DeXe DAO data — querying the subgraph, the backend and the chain, and pulling a whole DAO report — with the relevant tools for each and the known pitfalls. No args or a free-text `intent` returns the menu; `flow` returns the full topic. |
| `dexe_doctor` | Diagnose env setup | Diagnoses env setup — the cause and the fix of an env-related failure: presence + reachability checks (RPC, IPFS gateway DNS, subgraph, backend) as pass/warn/fail with remediation hints. Warnings are advisories — a healthy zero-config install always has some. |
| `dexe_get_config` | Resolved server config | (local, no network) The resolved read config: chain set and default chain, subgraph coverage per chain, the backend API and the IPFS read gateways. |

## DAO, proposal and vote reads

| Tool | Title | What it does |
|---|---|---|
| `dexe_dao_info` | DAO overview — helpers, NFT contracts, validator count | One multicall on a GovPool: helper addresses, NFT contract addresses, description URL, and live validator count. |
| `dexe_dao_registry_lookup` | Check whether an address is a DeXe GovPool | Calls `PoolRegistry.isGovPool(address)` — true when the address is a registered DeXe DAO GovPool. |
| `dexe_dao_predict_addresses` | Predict addresses for a future DAO deployment | Calls `PoolFactory.predictGovAddresses(deployer, poolName)` — the six CREATE2-predicted contract addresses for a DAO before it is deployed. |
| `dexe_proposal_state` | Live proposal state + required quorum | Reads `getProposalState`, `getProposalRequiredQuorum` and the proposal's votes in one multicall. `requiredQuorum` is an ABSOLUTE vote weight, not a percentage; quorum is per-side — either For or Against clearing it reaches quorum. |
| `dexe_proposal_list` | List proposals on a GovPool | Calls `GovPool.getProposals(offset, limit)` and adds quorum progress per proposal. Quorum is per-side — either For or Against clearing the target reaches it; `requiredQuorum` is an ABSOLUTE vote weight, not a percentage. |
| `dexe_proposal_voters` | Voter list for a proposal (subgraph) | Paginated voter list for one proposal from the pools subgraph (`proposalInteractions`). `chainId` picks the chain and the reply reports `indexedChainId`; a chain with no pools endpoint errors rather than answering from another index. |
| `dexe_vote_user_power` | User staking + delegation power across VoteTypes | Reads `tokenBalance` and `nftBalance` on GovUserKeeper for every VoteType (Personal/Micropool/Delegated/Treasury) in one multicall. tokenBalance includes the un-deposited wallet balance; deposited power = tokenBalance - tokenOwned. |
| `dexe_vote_get_votes` | User's votes on a specific proposal | Reads `GovPool.getUserVotes(proposalId, voter, voteType)` and returns the VoteInfoView. Defaults to PersonalVote. |

## On-chain and backend reads

| Tool | Title | What it does |
|---|---|---|
| `dexe_read_multicall` | Arbitrary batched eth_call via Multicall3 | N independent view calls in one Multicall3 round-trip; each supplies its own ABI signature fragment, target, method and args. |
| `dexe_read_treasury` | Treasury or wallet balances (native + ERC20, USD) | Treasury / wallet balances for any address; pass a GovPool address for a DAO treasury. Auto-discovers EVERY token via the DeXe backend with USD prices and a total. Falls back to an on-chain read (chain 97, explicit `tokens`, or a backend failure) — no token discovery there, and it reports `degraded: true`. |
| `dexe_read_token_holders` | Top holders of an ERC20 token (with balances) | Holders + raw balances for any ERC20 from the DeXe backend, balance desc, one page per call (see `pageToken`). Mainnets only (1, 56). |
| `dexe_read_dao_stats` | DAO TVL + activity stats time series | Time series of DAO stats (tvl_usd, member counts, proposal counts, delegations) from the DeXe tracker. `period` is a human duration like '24 hours', '7 days', '1 months'. Backend-only — mainnets. |
| `dexe_read_nfts` | NFTs held by an address | NFTs owned by any address via the DeXe backend (Moralis-backed). Backend-only — mainnets, not testnet 97. |
| `dexe_read_validators` | Validator count + isValidator lookup | Reads `validatorsCount()` and optionally `isValidator(candidate)` on the DAO's GovValidators, plus the validators' monthly credit lines (GovPool.getCreditInfo) — an internal monthly_withdraw against an unfunded line reverts. |
| `dexe_read_settings` | Default + internal proposal settings for a DAO | Reads `GovSettings.getDefaultSettings()` and `getInternalSettings()` for the DAO at `govPool` — quorum, duration, executionDelay, minVotesForCreating/Voting. |
| `dexe_read_protocol_stats` | Protocol-wide stats — TVL, proposals, DAOs across chains | The app.dexe.io landing numbers: TVL across ALL DAOs (aggregated over `chainIds`), proposals created, DAO count, voting-locked token value, 24h change percents, a TVL series, and optionally the top-N DAOs by TVL. Backend-only — mainnets (1, 56). |
| `dexe_read_expert_status` | Expert + BABT status for a user in a DAO | Reads `GovPool.getExpertStatus(user)` and, when the DAO has a BABT contract, `BABT.balanceOf(user) > 0`. |
| `dexe_read_token_sale_tiers` | Read token sale tier details | Reads `latestTierId()` and `getTierViews(offset, limit)` on a TokenSaleProposal. |
| `dexe_read_token_sale_user` | Read user participation status in token sale tiers | Reads `getUserViews(user, tierIds)` on a TokenSaleProposal — per-tier purchase status, claimable amounts, vesting info. |
| `dexe_read_distribution_status` | Check claimable amounts for distribution proposals | Per proposal id, reads `isClaimed(proposalId, voter)` and `getPotentialReward(proposalId, voter)` on a DistributionProposal. |
| `dexe_read_staking_info` | Read staking tier details and user info | Reads `stakingsCount()` and `getActiveStakings()` on a StakingProposal — pass its address, or a `govPool` to resolve it via GovUserKeeper.stakingProposalAddress(). With `user`, also reads `getUserInfo(user)`. |
| `dexe_read_privacy_policy_status` | Check privacy policy agreement status | Reads `UserRegistry.documentHash()` and `agreed(user)` — the current policy hash and whether the user agreed. |

## Subgraph reads

| Tool | Title | What it does |
|---|---|---|
| `dexe_graph_query` | Free-form GraphQL query against a DeXe subgraph | GraphQL against a DeXe subgraph: 'pools' (DAOs, proposals, voters, delegations, experts, sales), 'interactions' (per-user tx feed), 'validators'. Bound every list with `first:` (max 1000), page with `skip:`; oversized responses are rejected. Entity and field names must match the subgraph schema exactly — root fields are not entity names (DaoPool -> `daoPools`), and a wrong name errors with where to look it up. `chainId` picks the endpoint (pools: 56, validators: 56, interactions: 56; default 56); the reply echoes `indexedChainId`, never another chain's rows. |
| `dexe_graph_schema` | Introspect a DeXe subgraph schema | Live introspection of a DeXe subgraph schema — the valid names for a GraphQL query, e.g. after "Type 'X' has no field 'Y'". Omit `entity` for the root query field map (each entity -> the field name to query it by); pass `entity` for that type's fields, '<Entity>_filter' for valid `where:` keys, '<Entity>_orderBy' for valid `orderBy:` values. An unknown name returns ranked candidates. `chainId` picks the endpoint (pools: 56, validators: 56, interactions: 56; default 56); the reply echoes `indexedChainId`, never another chain's rows. |
| `dexe_read_dao_list` | Discover and list DAOs (subgraph) | Paginated DAO discovery via the pools subgraph; name search is case-insensitive, ordered by voter count descending. Pass `chainId` (chains with a pools endpoint here: 56; default 56); the reply echoes `indexedChainId`, never another chain's rows. No endpoint for a chain = an error that names the on-chain reads to use instead. |
| `dexe_read_dao_members` | List DAO members with voting power (subgraph) | Paginated member list for a DAO — voting power, delegation counts, rewards, expert status. Pass `chainId` (chains with a pools endpoint here: 56; default 56); the reply echoes `indexedChainId`, never another chain's rows. No endpoint for a chain = an error that names the on-chain reads to use instead. |
| `dexe_read_dao_experts` | List local experts in a DAO (subgraph) | Paginated list of local experts (holders of DAO-specific expert NFTs) with their delegation info. Pass `chainId` (chains with a pools endpoint here: 56; default 56); the reply echoes `indexedChainId`, never another chain's rows. No endpoint for a chain = an error that names the on-chain reads to use instead. |
| `dexe_read_delegation_map` | Delegation relationships — outgoing or incoming (subgraph) | Delegation pairs from the pools subgraph: direction='outgoing' = who a user delegated to, 'incoming' = who delegated to them. Pass `chainId` (chains with a pools endpoint here: 56; default 56); the reply echoes `indexedChainId`, never another chain's rows. No endpoint for a chain = an error that names the on-chain reads to use instead. |
| `dexe_read_user_activity` | User transaction history across DAOs (subgraph) | Paginated transaction history for a user — proposals created, votes cast, delegations, claims, newest first. Pass `chainId` (chains with a interactions endpoint here: 56; default 56); the reply echoes `indexedChainId`, never another chain's rows. No endpoint for a chain = an error that names the on-chain reads to use instead. |
| `dexe_read_validator_list` | List validators in a DAO (subgraph) | Paginated validator list ordered by balance descending. Pass `chainId` (chains with a validators endpoint here: 56; default 56); the reply echoes `indexedChainId`, never another chain's rows. No endpoint for a chain = an error that names the on-chain reads to use instead. |

## Token-sale reads

| Tool | Title | What it does |
|---|---|---|
| `dexe_read_token_sales` | List a DAO's token sale tiers | Reads `latestTierId()` then `getTierViews(0, latestTierId)` on the DAO's TokenSaleProposal: tiers with `totalSold` and status (`upcoming`/`active`/`ended`/`off`) computed from the current block timestamp and the tier's on-chain isOff flag. On-chain only — any chain with an RPC; the reply echoes the resolved `chainId`. `tokenSaleProposal` defaults to the address this install's local state records for the DAO; otherwise it is required. |
| `dexe_read_token_sale_position` | Token sale position for a wallet | Tier params + user state across N tiers: purchasable status, claimable amount, vesting withdrawable, lockup ETA, totalSold, merkle root. `whitelists` adds the user's proof, making `canParticipate` accurate for gated tiers. |

## Reporting and analysis

| Tool | Title | What it does |
|---|---|---|
| `dexe_dao_report` | Full DAO report — one call, every section, with a since-diff | The whole picture of one DAO in one call — every section named by `sections` (default all), plus everything with a DEADLINE: open votes, executable proposals and, with `user`, unvoted proposals and claimable rewards. Pass `since` (ISO timestamp, Unix seconds or `block:<n>`) for ONLY what changed since then. Sections degrade independently; unavailable ones are NAMED in `unavailable[]` with the reason. |
| `dexe_user_inbox` | Pending items for a wallet across DAOs | Pending items across N DAOs for a user: unvoted proposals in Voting state, claimable rewards, locked deposits. Discovery and scan both run on `chainId` (default 56). Omit `daos` to auto-discover from that chain's pools subgraph (limit 50; chains that can auto-discover here: 56); on a chain with none the DAOs this install's local state records on that chain are scanned instead, else pass `daos[]` — the scan itself is pure on-chain. The reply echoes `indexedChainId` and `daoSource`. |
| `dexe_proposal_forecast` | Forecast proposal pass rate and quorum | Reads the latest 10 proposals on a DAO and their final states and forecasts the pass-rate over DECIDED proposals (still-voting ones are `pending`, never failures), with the average For-vote weight. `quorum.requiredWeight` is an ABSOLUTE vote weight (getTotalPower x quorum / 1e27), not the 1e25 percentage setting. The history cross-check needs a pools subgraph for the chain being forecast; a chain with none is forecast on-chain only (`subgraphHistory: null`, `subgraphNote` says why) — never from another chain's index. `indexedChainId` reports whose index was used (null = none). |
| `dexe_proposal_risk_assess` | Analyze treasury risk of a proposal | Assesses low-quorum treasury risk and privileged no-value governance calls (blacklist, pause, changeVotePower, add/editSettings, changeExecutors, changeBalances). SAFE means 'no risk of the kinds this tool classifies', never 'this proposal is safe'. |

## IPFS

| Tool | Title | What it does |
|---|---|---|
| `dexe_ipfs_fetch` | Fetch content by CID (dedicated gateway, optional fallback) | Fetches IPFS content by CID through the server's gateway chain: its dedicated gateway first when it has one, then the configured or public fallbacks. |
| `dexe_ipfs_cid_info` | Parse an IPFS CID (version, codec, gateway URLs) | (local, no network) Parses a CIDv0/v1, reports codec + multihash, converts v0↔v1 when legal, and emits a URL per configured gateway. |

## Decoding and GovPool contract reads

| Tool | Title | What it does |
|---|---|---|
| `dexe_read_gov_state` | Read aggregate GovPool state | Reads `getHelperContracts()` and `getNftContracts()` on a GovPool. |
| `dexe_list_gov_contract_types` | DeXe governance contract catalog | (local, no network) Catalog of the DeXe governance contracts: what each does and where its source lives. |
| `dexe_decode_calldata` | Decode ABI-encoded calldata | (local, no network) Decodes '0x…' calldata against the DeXe Protocol ABIs (bundled; a local compile wins) — only `contract`'s when given, else every match. |
| `dexe_decode_proposal` | Read and decode a GovPool proposal | Fetches a GovPool proposal via `getProposals(offset, limit)` and decodes its for/against actions. |

## External Governors (OpenZeppelin / Compound Bravo)

| Tool | Title | What it does |
|---|---|---|
| `dexe_gov_list_governors` | List configured external Governor DAOs | (local, no network) Every bundled external-Governor config: its chain, governor address, voting token, voting params and timelock. A static snapshot — a DAO can change its params by proposal. |
| `dexe_gov_get_proposal` | Read OpenZeppelin Governor proposal state + tallies | ProposalState (name + enum index), snapshot block, deadline block and proposalVotes (for/against/abstain) for one proposal on a configured Governor. |
| `dexe_gov_get_voting_power` | Read IVotes voting power for an account | `IVotes.getPastVotes(account, blockNumber)` on the Governor's voting token, or `getVotes(account)` when blockNumber is omitted. Raw wei plus the token's decimals. |
| `dexe_gov_get_quorum` | Read Governor quorum threshold at a snapshot block | Quorum threshold at a snapshot block (latest when omitted). Bravo (UNI/COMP) reads fixed quorumVotes(); vanilla OZ reads quorum(blockNumber); OP-style governors, whose quorum() is keyed by proposalId, use votableSupply(block) * quorumNumerator/quorumDenominator. `method` reports the path taken, `configured` echoes the numerator/denominator to cross-check. |
| `dexe_gov_get_proposal_threshold` | Read Governor proposalThreshold() | `Governor.proposalThreshold()` — the voting power needed to submit a proposal. Returns the live uint256 plus the bundled config value, and whether they still agree. |
| `dexe_gov_get_state` | Read Governor.state() — minimal proposal-state lookup | `Governor.state(proposalId)` as {index, name} — one eth_call when the state is all you need. |
| `dexe_gov_has_voted` | Read whether an account has voted on a proposal | Whether the account already voted. OZ reads hasVoted(proposalId, account); Bravo has no hasVoted, so it reads getReceipt(proposalId, voter).hasVoted. |
| `dexe_gov_simulate_vote_impact` | Project proposal outcome after a hypothetical vote | Reads the live tallies + quorum and projects the outcome if `weight` of voting power were cast with `support`. Returns currentTallies, projectedTallies, quorumMet, willPass. Quorum counting follows the governor's COUNTING_MODE (`quorum.counting`): Bravo and CompoundGovernor count For only, vanilla OZ counts For+Abstain, Optimism counts all three. `willPass` ignores any per-proposal-type approvalThreshold or voting module — see `caveats` when present. |

## Notes for this server

- `dexe_dao_report` takes an explicit `since` anchor: an ISO-8601 time, Unix seconds or `block:<n>`. This server keeps no report snapshots, so `since: "last"` is refused. See [REPORTING.md](./REPORTING.md).
- This server keeps no local state between calls. Where a tool description mentions addresses "this install's local state records", nothing is recorded here: pass `tokenSaleProposal` to `dexe_read_token_sales` (the `govTokenSale` address from `dexe_dao_predict_addresses`, or the DAO's deploy receipt), and pass `daos[]` to `dexe_user_inbox` on chains without a pools subgraph. See [INBOX.md](./INBOX.md).
- `dexe_decode_calldata` and `dexe_decode_proposal` decode against an ABI snapshot of the DeXe Protocol contracts bundled in the package; no compile step is needed.
- The `dexe_gov_*` tools read external Governor DAOs on Ethereum (1) and Optimism (10). They work without configuration through a public fallback RPC; set an archive endpoint for historical reads. See [GOVERNOR.md](./GOVERNOR.md).
- `dexe_graph_query` needs exact entity and field names. Take them from `dexe_graph_schema` or [GRAPH.md](./GRAPH.md) (also the resource `dexe://graph-schema`).

## Resources

| URI | Content |
| --- | --- |
| `dexe://graph-schema` | Subgraph entity and field reference ([GRAPH.md](./GRAPH.md)) |
| `dexe://tools` | This catalog, rendered from the tools the server registered |
| `dexe://playbook` | Reading topics, pitfalls, and the error to remedy table for read failures |
