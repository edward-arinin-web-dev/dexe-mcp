# Running `dexe-mcp-read` locally and as a remote server

> **Status: pre-release.** The server is built for anonymous callers — read
> code only, no state, redacted diagnostics, hardened tools
> ([Tool-level limits](#tool-level-limits)) — but flags and env names may still
> change before 1.0.0. Not done yet: a public hosted endpoint
> (`https://{{MCP_HOST}}/mcp` below is a placeholder) and a verified Claude.ai
> custom connector against a live deployment. Both protocol eras, 2025-11-25
> and 2026-07-28, are served ([Protocol versions](#protocol-versions)).

`dexe-mcp-read` serves 54 tools that read DeXe DAO data — DAO profiles and
settings, treasury, proposals and their state, votes and voters, members, token
holders, delegation, validators and experts, token sales, staking, protocol
statistics — plus reads of external OpenZeppelin/Compound Governors. It runs
two ways:

| | Command | For |
| --- | --- | --- |
| stdio | `dexe-mcp-read` | your own MCP host (Claude Code, Claude Desktop, Cursor, …) |
| HTTP | `dexe-mcp-read serve-http` | operators hosting an endpoint for remote clients (Claude.ai custom connectors, ChatGPT developer mode, MCP Inspector) |

What makes it read-only is what it is built from, not a filter: the package
contains read code only. Nothing in it can sign, broadcast, pin to IPFS or build
a transaction to sign (a test walks the binary's import graph). It never
constructs a wallet. It speaks as `dexe-mcp-read` in the MCP handshake.

## Use it locally (stdio)

```bash
claude mcp add dexe-read -- npx -y -p @dexe-network/dexe-mcp dexe-mcp-read
```

Claude Desktop (`claude_desktop_config.json`) or any client that takes the
same shape:

```json
{
  "mcpServers": {
    "dexe-read": { "command": "npx", "args": ["-y", "-p", "@dexe-network/dexe-mcp", "dexe-mcp-read"] }
  }
}
```

- Works with zero configuration (public BSC RPC, subgraph endpoints, the DeXe
  backend and IPFS gateways are built in); `dexe_doctor` says what your own
  endpoints or Graph key would improve.
- Reads `.env` once at startup (`$DEXE_ENV_FILE`, `./.env`,
  `~/.dexe-mcp/.env`; the first file to set a key wins, and the MCP host's own
  env wins over every file). Signing keys and upload credentials in a shared
  `.env` are ignored and removed from the process.
- Keeps nothing between calls: no state file, no report snapshots. So
  `dexe_dao_report` takes an explicit `since` (ISO time, Unix seconds or
  `block:<n>`), and `since: "last"` is refused.
- `DEXE_TOOLSETS` means nothing here: all 54 tools are always served.
- Resources: `dexe://graph-schema` (subgraph entities), `dexe://tools` (this
  server's tool catalog, rendered from what it registered) and
  `dexe://playbook` (reading topics, pitfalls, and the error → remedy table
  for read failures).

## Connect a hosted endpoint (coming)

Once an endpoint is live, remote clients connect by URL with no
authentication:

- **Claude.ai:** Customize > Connectors > Add custom connector, URL
  `https://{{MCP_HOST}}/mcp`, no authentication.
- **ChatGPT:** Settings > Security and login > Developer mode, then create an
  app for `https://{{MCP_HOST}}/mcp` with no authentication.
- **MCP Inspector:** `npx @modelcontextprotocol/inspector`, Streamable HTTP
  transport, URL `https://{{MCP_HOST}}/mcp`.

Until then, run your own endpoint as described below.

## Host it (`serve-http`)

`dexe-mcp-read serve-http` serves the same 54 tools over MCP Streamable HTTP.
SIGTERM / SIGINT drain in-flight requests (up to 10 s) before the process exits.

- Stateless: no sessions, no `Mcp-Session-Id`, no `listChanged`, no sticky
  routing, and replicas need no coordination. One JSON-RPC message per POST;
  batches get 400. Every request gets a fresh server instance, so nothing one
  caller sent can reach the next. Requests that need no tool build none:
  notifications and posted responses are acknowledged with 202, and
  `initialize`, `server/discover`, `ping` and `subscriptions/listen` are answered
  by a server without tools (same identity, instructions and capabilities).
- Nothing on disk, nothing remembered between requests.
- Your infrastructure stays yours. Every result and error a caller gets names
  your endpoints by stable labels — `rpc[56]`, `subgraph:pools`, `backend`,
  `ipfs-gateway#1` — never by host, IP or port; a network error's peer reads
  `<upstream>`, and an IP address `<ip>`. (Public IPFS gateways such as
  `ipfs.io` keep their names, and a DAO's own links in its data are left
  alone.) `dexe_ipfs_fetch` reports the gateway that answered by its label.
  Labels are the same for every caller, so you can still match a user's report
  ("rpc[97] timed out") against your config.
- Nothing tells a caller to configure the server: a chain, subgraph or
  gateway you have not configured is "not available on this server", error
  remedies never mention a variable, a `.env` or a restart, and the guide and
  playbook describe this server.
- Diagnostics are redacted: `dexe_doctor` reports upstream health only (no env
  files or paths, which variables are set, rejected values, start time,
  endpoint hostnames or addresses, or remediation the caller cannot act on);
  `dexe_context` and `dexe_get_config` name no endpoint host.
- Configured by **process env only**. `.env` files (working directory,
  `~/.dexe-mcp/.env`, `DEXE_ENV_FILE`) are never read. At startup the process
  env is cut down to an allowlist, which keeps:
  - the read data-source variables listed below;
  - `DEXE_HTTP_*` and `DEXE_DEBUG`;
  - runtime basics such as `PATH`, `HOME`, `TMPDIR`, `TZ`, `NODE_*` and proxy/CA settings.

  Everything else is removed, including unrelated secrets such as `AWS_*`. The
  startup log records only how many variables were removed (`removedEnvVars`),
  not their names. Pass the container only the variables it needs: anything in
  a container's environment is visible to whoever can run `docker inspect` on
  the host, and a non-zero `removedEnvVars` is the sign to clean the env file up.

### Data sources are required

The package ships zero-config defaults so that local installs work out of the
box: public BSC RPCs, subgraph URLs that embed a shared Graph API key, and the
default DeXe backend. Every install shares them. A public server on these
defaults would spend everyone's quota and a billable key, so **`serve-http`
refuses to start on them**. The error message names the variables to set:

| Set | Replaces |
| --- | --- |
| `DEXE_RPC_URL_MAINNET` (and `DEXE_RPC_URL_TESTNET` for chain 97) | public BSC RPC fallback |
| `DEXE_SUBGRAPH_POOLS_URL`, `DEXE_SUBGRAPH_VALIDATORS_URL`, `DEXE_SUBGRAPH_INTERACTIONS_URL` | subgraph URLs carrying the shipped Graph key. Use URLs with your own key; a separate `DEXE_GRAPH_API_KEY` does not replace a key that is embedded in the URL. |
| `DEXE_BACKEND_API_URL` | the default backend. Setting it explicitly, even to `https://api.dexe.io`, counts as the operator's choice. |

`DEXE_HTTP_ALLOW_SHARED_DEFAULTS=1` starts the server anyway, logs a
`shared_defaults` warning, and is for **local testing only**. Also recommended:
`DEXE_IPFS_GATEWAY`, pointing at a dedicated gateway (the fallback is the free
public gateways).

### Run it

Docker, with the variables above in an env file that stays out of the image:

```sh
docker run -d --name dexe-mcp-read --restart unless-stopped \
  -p 127.0.0.1:8080:8080 --env-file ./remote.env \
  -e DEXE_HTTP_ALLOWED_HOSTS={{MCP_HOST}} -e DEXE_HTTP_TRUST_PROXY=1 \
  ghcr.io/dexe-network/dexe-mcp:latest
```

To build the image yourself from a checkout: `docker build -t dexe-mcp-read .`
Compose: copy `docker-compose.example.yml` from the repository, fill in the
endpoints, then run `docker compose up -d --build`.

Without Docker (Node 20.12 or later), with the data-source variables exported:

```sh
DEXE_HTTP_ALLOWED_HOSTS={{MCP_HOST}} npx -y -p @dexe-network/dexe-mcp dexe-mcp-read serve-http --host 0.0.0.0 --port 8080
```

The image:
- runs ONE file: the read binary bundled with its five runtime packages (MCP
  SDK, ethers, zod, multiformats, p-limit). No `node_modules`;
- uses `node:22-slim`, pinned by digest, and has no npm at runtime;
- runs as the unprivileged `node` user;
- writes nothing to disk, so it works with `read_only: true`;
- has a `HEALTHCHECK` on `/healthz`;
- starts `dexe-mcp-read serve-http` on `0.0.0.0:8080`, so
  `DEXE_HTTP_ALLOWED_HOSTS` is required.

### Endpoints

| Path | Method | Answer |
| --- | --- | --- |
| `/mcp` | POST | One MCP JSON-RPC message; answers in `application/json`. A JSON array (batch) gets 400 with code `-32600`. |
| `/mcp` | GET, DELETE | 405 (there is no SSE stream and no session) |
| `/mcp` | OPTIONS | CORS preflight, for allowlisted browser origins only |
| `/healthz` | GET | 200 while the process is up |
| `/readyz` | GET | 200 if one `eth_blockNumber` on the default chain answers within `DEXE_HTTP_READY_TIMEOUT_MS`, else 503. Cached for 5 s. |
| `/.well-known/openai-apps-challenge` | GET, HEAD | 200 with `DEXE_HTTP_OPENAI_CHALLENGE` as `text/plain`; 404 when that variable is unset. See [OpenAI domain verification](#openai-domain-verification). |

Every response has an `X-Request-Id` header, and the access log records the same id.

### Environment (HTTP layer)

Process env only. `--port` and `--host` override `PORT` and `DEXE_HTTP_HOST`.
`dexe-mcp-read serve-http --help` prints the same list.

| Variable | Default | Meaning |
| --- | --- | --- |
| `PORT` | `8080` | Listen port. 0 lets the OS pick one; the startup log shows which. |
| `DEXE_HTTP_HOST` | `127.0.0.1` (image: `0.0.0.0`) | Bind address. |
| `DEXE_HTTP_ALLOWED_HOSTS` | loopback names | Comma-separated hostnames the `Host` header may carry (port is ignored). **Required** off loopback: the server will not start without it. `*` turns the check off. |
| `DEXE_HTTP_ALLOWED_ORIGINS` | none | Exact browser origins, e.g. `https://inspector.example.com`. A request without an `Origin` header always passes; Claude.ai, ChatGPT, SDK clients and curl send none. A present, unlisted origin gets 403. `*` allows any origin. |
| `DEXE_HTTP_TRUST_PROXY` | off | How many reverse-proxy hops to trust for `X-Forwarded-For` (`true` = 1, max 10). Leave it off when nothing sits in front: clients can forge the header. |
| `DEXE_HTTP_MAX_BODY_BYTES` | `262144` | Request body cap; larger bodies get 413. |
| `DEXE_HTTP_BODY_TIMEOUT_MS` | `10000` | Time to receive the body once the headers are in; past it, 408 and the connection closes. |
| `DEXE_HTTP_RATE_LIMIT_PER_MIN` | `300` | Sustained requests per minute per client IPv4 address or IPv6 /64; 0 turns it off. Over it: 429 with `Retry-After`. |
| `DEXE_HTTP_RATE_LIMIT_BURST` | `60` | Requests one client may send back to back. |
| `DEXE_HTTP_MAX_INFLIGHT` | `32` | Concurrent MCP requests with a complete body, across all clients; over it: 503 with `Retry-After: 1`. Also caps abandoned requests whose tool call is still finishing ("draining"). |
| `DEXE_HTTP_REQUEST_TIMEOUT_MS` | `120000` | Budget for the MCP work once the body is in. Over it: 504, and the request's transport is closed so in-flight handlers are aborted. |
| `DEXE_HTTP_READY_TIMEOUT_MS` | `3000` | Budget for the `/readyz` RPC probe. |
| `DEXE_HTTP_ACCESS_LOG` | on | `0` turns the access log off. |
| `DEXE_HTTP_ALLOW_SHARED_DEFAULTS` | off | `1` = start on the shared built-in endpoints. Local testing only. |
| `DEXE_HTTP_OPENAI_CHALLENGE` | unset | Text served at `/.well-known/openai-apps-challenge` for OpenAI apps domain verification, unchanged except for trimmed outer whitespace (at most 4096 characters). |

Timeouts, in the order a request meets them:
1. Headers must arrive within 15 s. Node answers 408 otherwise.
2. The body must arrive within `DEXE_HTTP_BODY_TIMEOUT_MS`.
3. The MCP work then has `DEXE_HTTP_REQUEST_TIMEOUT_MS`.

A request takes an in-flight slot only once its body is complete, so slow
uploads cannot lock other clients out. Idle keep-alive connections close after
65 s, which is longer than the usual 60 s load-balancer idle timeout.

Data-source variables use the same names as stdio mode (see
[ENVIRONMENT.md](ENVIRONMENT.md)): `DEXE_RPC_URL_*`, `DEXE_SUBGRAPH_*`,
`DEXE_GRAPH_API_KEY`, `DEXE_BACKEND_API_URL`, `DEXE_IPFS_GATEWAY`,
`DEXE_IPFS_GATEWAYS_FALLBACK`, `DEXE_PINATA_GATEWAY_TOKEN`,
`DEXE_DEFAULT_CHAIN_ID`, `DEXE_RPC_TIMEOUT_MS`, and the limits
`DEXE_IPFS_MAX_BYTES` and `DEXE_MAX_RESPONSE_BYTES` (see
[Tool-level limits](#tool-level-limits)).

### Tool-level limits

Every read tool has these limits, on stdio and over HTTP alike:

| Limit | Default | Set with | What happens past it |
| --- | --- | --- | --- |
| IPFS body | 2 MB | `DEXE_IPFS_MAX_BYTES` | The body is streamed and the fetch stops at the limit with an error. No other gateway is asked for the same CID. `dexe_ipfs_fetch` also summarizes parsed JSON over 128 KB (`truncated: true`, `sizeBytes` is the real size). |
| Tool result | 256 KB | `DEXE_MAX_RESPONSE_BYTES` | Rows are dropped from the end and long strings shortened until the result fits. The first line says `RESPONSE TRUNCATED`, what was cut and how to get the rest. Offset-paged tools report a corrected `returned` and `nextOffset`. |
| Array inputs | per tool (for example 8 `chainIds`, 100 `calls`, 50 `daos`) | not configurable | Schema validation rejects the call before any upstream request. |
| Third-party strings in `structuredContent` | 16,000 characters each | not configurable | The string is cut with a marker. Hex data is never cut. |
| Subgraph and backend JSON | 16 MB | not configurable | The call fails with a hint to request fewer rows. |

Tool results and errors never contain the configured RPC, subgraph, backend or
gateway URLs or keys. A last-pass scrub replaces any of them, even one echoed
back by an upstream, with a masked form such as `https://host/***`.
IPFS gateways are named by host only.

When a request is cancelled or hits `DEXE_HTTP_REQUEST_TIMEOUT_MS`, the tool
stops: in-flight IPFS, subgraph and backend requests are aborted, no further
upstream calls are made, and an RPC read stops retrying and stops waiting. A
JSON-RPC request already sent still runs to its own `DEXE_RPC_TIMEOUT_MS` (ethers
takes no abort signal), but its answer is discarded.

A request whose response is gone while its tool call is still running moves
from "in flight" to "draining" and keeps its slot there until the call ends.
Draining requests are capped at `DEXE_HTTP_MAX_INFLIGHT` too; past that, new
MCP requests get 503 (`reason: "draining"`) until abandoned work finishes, so
calls that ignore cancellation can never pile up in memory. At most
2 × `DEXE_HTTP_MAX_INFLIGHT` tool calls ever run at once. A draining slot is
released after max(120 s, 2 × `DEXE_HTTP_REQUEST_TIMEOUT_MS`); work still running
then counts as stuck, and once `DEXE_HTTP_MAX_INFLIGHT` calls are stuck, tool
requests get 503 (`reason: "stuck"`, `Retry-After: 30`) until they end.
`initialize`, `server/discover`, `ping` and `subscriptions/listen` start no
tool call and are never refused for abandoned work.

### OpenAI domain verification

Publishing an app for ChatGPT may require proving that you control the
endpoint's domain by serving a token at `/.well-known/openai-apps-challenge`.
Put the token OpenAI gives you in `DEXE_HTTP_OPENAI_CHALLENGE` and restart:

```bash
docker run … -e DEXE_HTTP_OPENAI_CHALLENGE='<token from OpenAI>' ghcr.io/dexe-network/dexe-mcp:<version>
curl -i https://{{MCP_HOST}}/.well-known/openai-apps-challenge
```

- The value is served **as-is** as `text/plain; charset=utf-8` (outer
  whitespace trimmed). OpenAI's exact expected response format is not verified
  here. If their instructions ask for a different body, such as JSON or a
  `key=value` line, put exactly that text in the variable.
- The path checks the `Host` allowlist and the per-IP rate limit like `/mcp`.
  It skips the `Origin` check and sends no CORS headers, because the verifier
  fetches it server to server.
- Unset (the default), the path answers 404. The token is not written to the
  access log.
- Behind a reverse proxy, forward this path too (see the `location` below).

### Reverse proxy and TLS

The server speaks plain HTTP. Terminate TLS in front of it.

```nginx
location /mcp {
    proxy_pass http://127.0.0.1:8080;
    proxy_set_header Host $host;                 # must match DEXE_HTTP_ALLOWED_HOSTS
    proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    proxy_read_timeout 130s;                      # above DEXE_HTTP_REQUEST_TIMEOUT_MS
    client_max_body_size 256k;
    client_body_timeout 10s;
}
location = /healthz { proxy_pass http://127.0.0.1:8080; }
location = /readyz  { proxy_pass http://127.0.0.1:8080; }
location = /.well-known/openai-apps-challenge { proxy_pass http://127.0.0.1:8080; proxy_set_header Host $host; }
```

- Forward the original `Host`, or add the upstream name to `DEXE_HTTP_ALLOWED_HOSTS`.
- With one proxy in front, set `DEXE_HTTP_TRUST_PROXY=1`. Otherwise every
  client shares the proxy's IP and one rate-limit bucket.
- Serve `/mcp` at the URL you register, without redirects. Claude drops
  credentials on a cross-host redirect and reports a connection error.
- Publish an IPv4 `A` record. Claude.ai connectors connect over IPv4 only.
- Do not let a WAF or bot filter answer 403 or 429 to the AI clients'
  backends. Claude.ai connects from Anthropic's published egress range
  (see <https://platform.claude.com/docs/en/api/ip-addresses>).

### Rate-limit tuning

The limit is kept in memory per process, and each IPv4 address or IPv6 /64 is
one bucket. Claude.ai and ChatGPT call the server from their own backends, so
many end users arrive from a few addresses, and consecutive requests from one
session can come from different addresses. Connecting takes a handful of
requests. The SDK client sends `initialize`, `notifications/initialized`, a
`GET` (answered 405) and `tools/list`, and dual-era clients first probe
`server/discover`. After that, each tool call is one request. If those backends
get a 429 while connecting, users see "couldn't reach the server".

So the per-IP limit really limits *a client platform*, not a person: every
Claude.ai user of your connector shares the buckets of Anthropic's egress
addresses, every ChatGPT user OpenAI's. Size `DEXE_HTTP_RATE_LIMIT_PER_MIN` and
`DEXE_HTTP_RATE_LIMIT_BURST` for the traffic of all their users together —
roughly (concurrent users) × (tool calls a user makes per minute), plus a burst
of 10–20 per connecting session — not for one person. A starting point for a
public connector: `DEXE_HTTP_RATE_LIMIT_PER_MIN=3000`, `DEXE_HTTP_RATE_LIMIT_BURST=300`,
raised when the access log shows `"reason":"rate"` for those address ranges.
If you need per-user fairness, enforce it at the proxy (it sees more than an
IP). `DEXE_HTTP_MAX_INFLIGHT` is the backstop that protects your RPC and
subgraph quotas whatever the rate limit lets through.

### Protocol versions

One endpoint, `/mcp`, serves both protocol eras:

| Era | Revisions | How a client arrives | Answers |
| --- | --- | --- | --- |
| legacy | `2024-10-07` … `2025-11-25` | `initialize` handshake; no `_meta` envelope on requests | `application/json` |
| modern | `2026-07-28` | `server/discover`, then every request carries its `_meta` envelope and `Mcp-Method` / `Mcp-Name` headers | `application/json` |

Every request passes the same admission checks first — Host, Origin and CORS,
method, rate limit, media type, body size and deadline, JSON parse, batch
rejection, in-flight cap — and only then is routed to an era by the SDK's own
classifier: a request without the per-request `_meta` envelope is legacy,
everything else (malformed envelopes included) is modern. A dual-era client
(Claude Code, the TypeScript SDK v2 client in negotiation `auto`) probes with
`server/discover` and gets the modern era; a 2025-only client's `initialize`
gets the legacy era. Neither era needs a session or a prior handshake on the
same node.

The modern era answers the 2026-07-28 errors itself: `-32020` when the
`Mcp-Method` / `Mcp-Name` headers disagree with the body, `-32022` (with
`data.supported`) for a revision it does not serve, `-32602` for a malformed
envelope. `server/discover` lists only `["2026-07-28"]` in
`supportedVersions`; 2025-era revisions are negotiated through `initialize`,
as the spec intends. The server advertises `listChanged: false`, so a
`subscriptions/listen` is acknowledged and closed at once.

stdio serves both eras the same way: the client's opening message picks the
era for the connection.

### Logs

Logs are JSON lines. Startup, config notes and errors go to stderr. The access
log goes to stdout:

```json
{"ts":"…","event":"http","reqId":"…","method":"POST","path":"/mcp","ip":"3f9a1c0b7d2e","ua":"…","proto":"2026-07-28","bytesIn":131,"rpc":"tools/call","tool":"dexe_read_treasury","era":"modern","status":200,"ms":412}
```

Access log entries never contain request or response bodies, tool arguments,
or raw IP addresses. `ip` is a salted hash, and the salt changes on every
restart. `era` (`legacy` / `modern`) is the protocol era the request was
served in; a request refused before routing has none. Rejected requests carry
a `reason`: `host`, `origin`, `method`, `rate`, `content-type`, `accept`,
`body`, `body-timeout`, `parse`, `batch`, `invalid`, `inflight`, `draining`,
`stuck`, `timeout`, `factory`.

### Verify

```sh
curl -s https://{{MCP_HOST}}/healthz
curl -s https://{{MCP_HOST}}/readyz
curl -s https://{{MCP_HOST}}/mcp \
  -H 'content-type: application/json' -H 'accept: application/json, text/event-stream' \
  -d '{"jsonrpc":"2.0","id":1,"method":"initialize","params":{"protocolVersion":"2025-11-25","capabilities":{},"clientInfo":{"name":"curl","version":"0"}}}'
# 2026-07-28: no handshake; the request carries its own envelope and headers
curl -s https://{{MCP_HOST}}/mcp   -H 'content-type: application/json' -H 'accept: application/json, text/event-stream'   -H 'mcp-protocol-version: 2026-07-28' -H 'mcp-method: server/discover'   -d '{"jsonrpc":"2.0","id":1,"method":"server/discover","params":{"_meta":{"io.modelcontextprotocol/protocolVersion":"2026-07-28","io.modelcontextprotocol/clientCapabilities":{},"io.modelcontextprotocol/clientInfo":{"name":"curl","version":"0"}}}}'
```

The `initialize` should answer with `"serverInfo":{"name":"dexe-mcp-read",…}`, the
`server/discover` with `"supportedVersions":["2026-07-28"]`, and a
`tools/list` with 54 tools. Then connect a client as in
[Connect a hosted endpoint](#connect-a-hosted-endpoint-coming); with the MCP
Inspector's direct browser mode, add its origin to `DEXE_HTTP_ALLOWED_ORIGINS`.
