# Environment variables — `dexe-mcp-read`

Every variable is **optional**. The server ships public defaults, so all 54
tools work with no configuration at all. Set a variable to use your own
endpoint, key or limit; your value always wins over the built-in default.

After changing anything, restart the MCP host (or the server process): the env
is read once at startup. `dexe_doctor` reports what was loaded and what an
upgrade would improve; `dexe_get_config` shows the resolved chains, subgraph
coverage, backend and IPFS gateways.

## 1. How configuration is loaded

**stdio (`dexe-mcp-read`).** At startup the server loads each of these files
that exists, in order. The first file to set a key wins, and a variable already
in the process environment (for example the MCP host's `env` block) wins over
every file:

1. `$DEXE_ENV_FILE` — an absolute path, set in the real process environment.
2. `<cwd>/.env` — the working directory.
3. `~/.dexe-mcp/.env` — the home config; works from any folder on macOS, Linux
   and Windows. Recommended for `npx` and plugin installs.
4. the `.env` next to the installed package (rarely present).

Prefer a `.env` file over the MCP host's `env` block: a key set in the host
config silently shadows the same key in every file.

**A shared `.env` is fine.** If the same file also holds keys for other tools —
signing keys, upload credentials, wallet-connection settings — this server
ignores them: they are never parsed, never reported as unknown, and are removed
from the process right after loading.

**HTTP (`dexe-mcp-read serve-http`).** Process environment only; no `.env` file
is ever read. The env is reduced to an allowlist of the read variables below,
`DEXE_HTTP_*`, `DEXE_DEBUG` and runtime basics; everything else is removed at
startup. The HTTP variables are in [REMOTE.md](./REMOTE.md#environment-http-layer),
including `DEXE_HTTP_OPENAI_CHALLENGE`: the text served at
`/.well-known/openai-apps-challenge` for OpenAI apps domain verification (unset:
404). The response format OpenAI expects is not verified here, so the value is
served raw; see [REMOTE.md](./REMOTE.md#openai-domain-verification).

## 2. What works with zero config

| Surface | Built-in default | Override with |
| --- | --- | --- |
| On-chain RPC | public BSC nodes for chains 56 and 97 (default 56) | `DEXE_RPC_URL_MAINNET` / `DEXE_RPC_URL_TESTNET`, or `DEXE_DISABLE_PUBLIC_RPC=1` |
| ContractsRegistry (56, 97) | the canonical DeXe address | `DEXE_CONTRACTS_REGISTRY` |
| Subgraph reads (chain 56 only) | shared endpoints on The Graph's decentralized gateway, key in the URL | `DEXE_SUBGRAPH_*_URL`; other chains: `DEXE_SUBGRAPH_<KIND>_URL_<chainId>` |
| DeXe backend (chain 56) | `https://api.dexe.io` | `DEXE_BACKEND_API_URL` |
| IPFS reads | public gateways (`ipfs.io`, `dweb.link`, `cloudflare-ipfs.com`) | `DEXE_IPFS_GATEWAY`, or `DEXE_IPFS_DISABLE_PUBLIC_FALLBACK=1` |
| External Governor chains (1, 10) | a shared public endpoint per chain | `DEXE_RPC_URL_1`, `DEXE_RPC_URL_10` ([GOVERNOR.md](./GOVERNOR.md#runtime-rpc-setup)) |

The shared defaults are rate-limited, and the shared Graph key is billed to
whoever owns it. They are fine for light use; for anything regular, set your own
RPC and Graph key. `dexe_doctor` flags shared defaults as an advisory, and
`serve-http` refuses to start on them (see [REMOTE.md](./REMOTE.md#data-sources-are-required)).

## 3. Reference

| Variable | Default | Meaning |
| --- | --- | --- |
| **RPC** | | |
| `DEXE_RPC_URL_MAINNET` | public BSC nodes | RPC for BSC mainnet (56). A comma-separated list: the first is primary, the rest rotate on transport failures. |
| `DEXE_RPC_URL_TESTNET` | public BSC testnet nodes | RPC for BSC testnet (97). Same list form. |
| `DEXE_RPC_URL_<chainId>` | — | RPC for any other chain, e.g. `DEXE_RPC_URL_1` (Ethereum), `DEXE_RPC_URL_10` (Optimism). |
| `DEXE_RPC_URL`, `DEXE_CHAIN_ID` | — | Legacy single-chain form. `DEXE_CHAIN_ID` is inferred from the hostname when unset. Prefer the per-chain names. |
| `DEXE_DEFAULT_CHAIN_ID` | see [§4](#4-chains) | Chain used when a tool omits `chainId`. Must be a configured chain. |
| `DEXE_RPC_TIMEOUT_MS` | `10000` | Timeout for one JSON-RPC request. On timeout the request fails fast and rotates to the next URL. |
| `DEXE_DISABLE_PUBLIC_RPC` | off | `1` turns off the built-in public RPC fallback (BSC 56 and 97 when no RPC is set at all, and the Governor chains). |
| `DEXE_CONTRACTS_REGISTRY` | built in for 56 and 97 | ContractsRegistry address for the default chain. Rarely needed. |
| **Subgraph** | | |
| `DEXE_SUBGRAPH_POOLS_URL` | shared chain-56 endpoint | Pools subgraph (DAOs, proposals, voters, delegations, experts). |
| `DEXE_SUBGRAPH_VALIDATORS_URL` | shared chain-56 endpoint | Validators subgraph. |
| `DEXE_SUBGRAPH_INTERACTIONS_URL` | shared chain-56 endpoint | Interactions subgraph (per-user activity feed). |
| `DEXE_SUBGRAPH_<KIND>_URL_<chainId>` | — | Per-chain form of the three above, e.g. `DEXE_SUBGRAPH_POOLS_URL_97`. Wins for that chain. |
| `DEXE_SUBGRAPH_CHAIN_ID` | `56` | The chain the unsuffixed `DEXE_SUBGRAPH_*_URL` endpoints index. |
| `DEXE_GRAPH_API_KEY` | — | The Graph API key sent as a bearer token. A key embedded in the URL path does not need it. |
| **Backend** | | |
| `DEXE_BACKEND_API_URL` | `https://api.dexe.io` | DeXe backend API root: treasury discovery with USD prices, token holders, DAO and protocol stats, NFTs, off-chain proposal data. Indexes the mainnets only. |
| **IPFS** | | |
| `DEXE_IPFS_GATEWAY` | — | Dedicated IPFS gateway for reads, tried first. |
| `DEXE_IPFS_GATEWAYS_FALLBACK` | public gateways | Comma-separated fallback gateways, tried in order after the primary. |
| `DEXE_IPFS_DISABLE_PUBLIC_FALLBACK` | off | `1` drops the public gateways; reads then need `DEXE_IPFS_GATEWAY`. |
| `DEXE_PINATA_GATEWAY_TOKEN` | — | Access token for a private Pinata dedicated gateway (reads only). |
| `DEXE_IPFS_MAX_BYTES` | `2097152` (2 MB) | Byte limit for one IPFS read; clamped to 1 KB–256 MB. |
| **Limits and analysis** | | |
| `DEXE_MAX_RESPONSE_BYTES` | `262144` (256 KB) | Size limit for one tool result; a larger result is cut to fit with a note saying what was cut. Clamped to 16 KB–16 MB. |
| `DEXE_MIN_SAFE_QUORUM_PCT` | `50` | Quorum percent below which `dexe_proposal_risk_assess` flags treasury-moving proposals. |
| `DEXE_CONTROLLING_TOPN` | `5` | Top-N holders by voting weight that `dexe_proposal_risk_assess` treats as the controlling set, alongside validators. Needs pools and validators subgraphs for the chain. |
| **Diagnostics** | | |
| `DEXE_DEBUG` | off | `1` writes verbose, redacted diagnostics to stderr (never stdout). Enable it before filing a bug report. |
| `DEXE_ENV_FILE` | — | Absolute path to a `.env` file to load first (stdio only). Must be set in the real process environment. |

**Recognized, no effect in this server.** `DEXE_TOOLSETS` (all 54 tools are
always served; the stdio binary prints a notice when it is set),
`DEXE_STATE_PATH` (this server keeps no state file) and `DEXE_DOCTOR_STRICT`
(used by the doctor CLI that programs built on `@dexe-network/dexe-mcp/core`
can expose).

## 4. Chains

**Which chains are configured, and which is the default:**

| You set | Chains | Default chain |
| --- | --- | --- |
| no RPC at all | 56 and 97 on the public fallback | 56 |
| one RPC (e.g. only `DEXE_RPC_URL_MAINNET`) | that chain only | that chain |
| several RPCs, no `DEXE_DEFAULT_CHAIN_ID` | those chains | 97 if configured, else the lowest chain id |
| `DEXE_DEFAULT_CHAIN_ID=<n>` | as above | `<n>` (must be one of them) |

Setting **any** RPC variable turns the built-in BSC fallback off, including a
Governor-only `DEXE_RPC_URL_1`. If you add an RPC for one chain and still want
the others, set them too, and pin the default:

```env
DEXE_RPC_URL_MAINNET=https://<your-bsc-rpc>
DEXE_RPC_URL_1=https://<your-ethereum-archive-rpc>
DEXE_DEFAULT_CHAIN_ID=56
```

**BSC mainnet (56)** is the zero-config default and the only chain with DeXe
subgraphs and the DeXe backend. Everything works out of the box.

**BSC testnet (97)** has on-chain reads only. There is no public DeXe subgraph
or backend for it, so the subgraph tools (`dexe_proposal_voters`,
`dexe_graph_query`, `dexe_graph_schema`, `dexe_read_dao_list`,
`dexe_read_dao_members`, `dexe_read_delegation_map`, `dexe_read_dao_experts`,
`dexe_read_validator_list`, `dexe_read_user_activity`) refuse chain-97 reads
with the on-chain alternatives (`dexe_read_gov_state`, `dexe_proposal_list`,
`dexe_read_multicall`), and the backend tools answer for the mainnets only.
Point `DEXE_SUBGRAPH_<KIND>_URL_97` at your own indexer to enable the subgraph
tools.

**Other EVM chains** need a DeXe `ContractsRegistry` deployment:

```env
DEXE_RPC_URL_<chainId>=https://...
DEXE_DEFAULT_CHAIN_ID=<chainId>
DEXE_CONTRACTS_REGISTRY=0x<registry>
```

**External Governor DAOs** live on Ethereum (1) and Optimism (10); see
[GOVERNOR.md](./GOVERNOR.md#runtime-rpc-setup).

## 5. IPFS

The public gateways throttle and occasionally disagree on freshly pinned
content. For regular use set a dedicated gateway:

```env
DEXE_IPFS_GATEWAY=https://<your-gateway-host>
# optional, for a private Pinata dedicated gateway:
DEXE_PINATA_GATEWAY_TOKEN=<token>
```

Fallbacks are tried one after another, not in parallel:

```env
DEXE_IPFS_GATEWAYS_FALLBACK=https://dweb.link,https://ipfs.io
```

## 6. Backend

`DEXE_BACKEND_API_URL` serves `dexe_read_treasury` (token discovery and USD
prices), `dexe_read_token_holders`, `dexe_read_dao_stats`,
`dexe_read_protocol_stats` and `dexe_read_nfts`. `dexe_read_treasury` falls back
to an on-chain read (no token discovery, `degraded: true`) when the backend is
unavailable or the chain is not indexed.

## 7. Limits

See [REMOTE.md](./REMOTE.md#tool-level-limits) for the IPFS byte cap, the
result-size cap, the per-tool array limits and the untrusted-string cap. They
apply on stdio and over HTTP alike.

## 8. Subgraph configuration

Subgraph reads work with no config: they default to shared DeXe endpoints on
The Graph's decentralized network, with an API key embedded in the URL path.
Set these variables to use your own key, which is recommended for regular use.

The gateway URL form, with your key in the path:

```
https://gateway.thegraph.com/api/<API_KEY>/subgraphs/id/<SUBGRAPH_ID>
```

A 401 almost always means the key is missing from the URL.

```env
DEXE_SUBGRAPH_POOLS_URL=https://gateway.thegraph.com/api/<key>/subgraphs/id/<pools-id>
DEXE_SUBGRAPH_VALIDATORS_URL=https://gateway.thegraph.com/api/<key>/subgraphs/id/<validators-id>
DEXE_SUBGRAPH_INTERACTIONS_URL=https://gateway.thegraph.com/api/<key>/subgraphs/id/<interactions-id>
```

### One endpoint indexes one chain

Every subgraph-backed tool takes `chainId` and resolves its endpoint per
(kind, chain):

| # | Source | Covers |
| --- | --- | --- |
| 1 | `DEXE_SUBGRAPH_<KIND>_URL_<chainId>` | that chain — wins outright |
| 2 | `DEXE_SUBGRAPH_<KIND>_URL` | the chain named by `DEXE_SUBGRAPH_CHAIN_ID` (default `56`), and only that chain |
| 3 | built-in default | chain `56`, and only chain `56` |

There is no cross-chain fallback. A chain that matches none of the three has no
endpoint, and the read fails with a message naming the on-chain alternatives,
rather than answering with another chain's rows. Every response carries
`indexedChainId`, the chain the rows came from.

`dexe_get_config` shows what resolved under `subgraph`: `chainsCovered`,
`byKind`, `missingForDefaultChain` and `unsuffixedVarsChainId`.

To add your own testnet indexer:

```env
DEXE_SUBGRAPH_POOLS_URL_97=https://gateway.thegraph.com/api/<key>/subgraphs/id/<pools-id-97>
DEXE_SUBGRAPH_VALIDATORS_URL_97=https://gateway.thegraph.com/api/<key>/subgraphs/id/<validators-id-97>
DEXE_SUBGRAPH_INTERACTIONS_URL_97=https://gateway.thegraph.com/api/<key>/subgraphs/id/<interactions-id-97>
```

If all your endpoints index one non-mainnet chain, you can keep the unsuffixed
names and declare the chain once with `DEXE_SUBGRAPH_CHAIN_ID=<chainId>`. Chain
56 then keeps resolving to the built-in mainnet defaults.

## 9. Common pitfalls

**`.env` syntax.** The file is parsed by Node's built-in loader, which is strict:
no spaces around `=` (`FOO=bar`, not `FOO = bar`); end the file with a newline;
quotes are literal unless the value needs them; comments only on their own line;
no UTF-8 byte-order mark.

**Edits do nothing until a restart.** The env is read once at startup. Restart
the MCP host (Claude Desktop: quit and relaunch; Claude Code: restart the
session or reconnect the server with `/mcp`).

**A value seems ignored.** The MCP host's `env` block wins over every `.env`
file. Remove the key from the host config, or set it there instead.

**"No DeXe `<kind>` subgraph is configured for chain N".** Chain N has no
indexer. Pass `chainId: 56` if mainnet is what you meant, read chain N on-chain
instead (`dexe_read_gov_state`, `dexe_proposal_list`, `dexe_read_multicall`), or
set `DEXE_SUBGRAPH_<KIND>_URL_<N>` to your own indexer and restart.

**"Set DEXE_CONTRACTS_REGISTRY or pick a supported chain".** The chain has no
built-in registry address. Use 56 or 97, or set `DEXE_CONTRACTS_REGISTRY`.

**Governor reads fail on historical blocks.** The free public endpoints refuse
archive reads. Set an archive `DEXE_RPC_URL_1` / `DEXE_RPC_URL_10`; never use
`DEXE_RPC_URL_MAINNET` for them (it means BSC chain 56).
